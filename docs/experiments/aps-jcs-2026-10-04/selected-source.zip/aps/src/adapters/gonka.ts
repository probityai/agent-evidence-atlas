// Copyright (c) 2026 Tymofii Pidlisnyi
// SPDX-License-Identifier: Apache-2.0
/**
 * Gonka Adapter — Governance layer for decentralized GPU inference networks
 *
 * Replaces Gonka's primitive allowlist.csv + manual governance votes with
 * APS delegation chains: automatic expiry, monotonic narrowing, cascade
 * revocation, signed receipts for off-chain devshard settlement.
 *
 * No Gonka SDK dependency. All types are local interfaces.
 */

import { createHash } from 'node:crypto'
import { scopeAuthorizes, verifyDelegation, type RevocationCheckOptions } from '../core/delegation.js'
import { checkPassportTrustPosture } from '../verification/trust-posture.js'
import { sign } from '../crypto/keys.js'
import { canonicalize, canonicalizeForWrite } from '../core/canonical.js'
import type { Delegation, ActionReceipt, SignedPassport } from '../types/passport.js'

// ── Types ──

export interface GonkaInferenceRequest {
  model: string
  prompt: string
  maxTokens?: number
  hostAddress?: string
  epochId?: number
  devshardId?: string
}

export interface GonkaHostConfig {
  passport: SignedPassport
  delegation: Delegation
  privateKey: string
  allowedModels?: string[]
  maxInferencesPerEpoch?: number
  onReceipt?: (r: ActionReceipt) => void
  onDenied?: (info: { host: string; reason: string }) => void
  /** Trust anchors for this gate: issuer public keys whose countersignature
   *  is accepted. A NON-EMPTY list requires a valid countersignature from one
   *  of them. An empty list, or omitting it, means this gate holds no
   *  anchors; it does not mean "trust anyone". */
  trustedIssuers?: string[]
  /** Explicit wildcard trust: admit a passport whose only authority is its
   *  own signature. Required to admit a self-signed credential, because a
   *  signature that verifies under a key the passport itself supplied is not
   *  an authorization by a trusted issuer. Default false. */
  allowSelfSigned?: boolean
  /** Revocation posture applied to the delegation check before every
   *  governed call. This adapter is an execution gate: it verifies the
   *  delegation immediately before the tool runs, which is exactly where a
   *  caller who will not act on unknown revocation state says so. Pass
   *  { revocationCheckPolicy: 'fail_closed', cachedRevocationState } to
   *  refuse when revocation evidence is absent or stale. Omitted leaves the
   *  previous behaviour, signature and expiry only. */
  revocation?: RevocationCheckOptions
}

export interface GonkaInferenceReceipt {
  receipt: ActionReceipt
  model: string
  epochId?: number
  devshardId?: string
  inferenceHash: string
}

export interface GonkaHostVerification {
  authorized: boolean
  reason: string
  scope: string
  hostAddress: string
  model: string
}

// ── Helpers ──

function sha256(data: string): string {
  return createHash('sha256').update(data).digest('hex')
}

function buildReceipt(
  agentId: string, delegationId: string, privateKey: string,
  target: string, scope: string, status: 'success' | 'failure', summary: string,
): ActionReceipt {
  const data: Omit<ActionReceipt, 'signature'> = {
    receiptId: `rcpt_gonka_${Date.now().toString(36)}_${Math.random().toString(36).slice(2, 6)}`,
    version: '1.1',
    timestamp: new Date().toISOString(),
    agentId, delegationId,
    action: { type: 'gonka_inference', target, scopeUsed: scope },
    result: { status, summary },
    delegationChain: [],
  }
  const sig = sign(canonicalizeForWrite(data), privateKey)
  return { ...data, signature: sig } as ActionReceipt
}

// Track inferences per epoch for rate limiting
const epochCounters = new Map<string, number>()

function getEpochKey(agentId: string, epochId?: number): string {
  return `${agentId}:${epochId ?? 'default'}`
}

// ── Core functions ──

/** Verify a host has authority to serve inference for a model */
export function verifyGonkaHost(
  hostAddress: string,
  model: string,
  config: GonkaHostConfig,
): GonkaHostVerification {
  const scope = `inference:serve:${model}`

  const pc = checkPassportTrustPosture(config.passport, config)
  if (!pc.ok) {
    return { authorized: false, reason: pc.detail ?? 'Passport rejected at the gate', scope, hostAddress, model }
  }

  const dc = verifyDelegation(config.delegation, config.revocation)
  if (!dc.valid) {
    return { authorized: false, reason: `Delegation invalid: ${dc.errors.join(', ')}`, scope, hostAddress, model }
  }

  if (config.allowedModels && config.allowedModels.length > 0 && !config.allowedModels.includes(model)) {
    return { authorized: false, reason: `Model "${model}" not in allowed models`, scope, hostAddress, model }
  }

  if (!scopeAuthorizes(config.delegation.scope, scope)) {
    return { authorized: false, reason: `Scope "${scope}" not covered by delegation [${config.delegation.scope.join(', ')}]`, scope, hostAddress, model }
  }

  return { authorized: true, reason: `Host authorized to serve ${model}`, scope, hostAddress, model }
}

/** Govern an inference request -- check delegation, model, rate limits */
export async function governGonkaInference(
  request: GonkaInferenceRequest,
  execute: (req: GonkaInferenceRequest) => Promise<{ response: string; tokensUsed: number }>,
  config: GonkaHostConfig,
): Promise<{ result: { response: string; tokensUsed: number }; receipt: GonkaInferenceReceipt } | { denied: true; reason: string; receipt: ActionReceipt }> {
  const host = request.hostAddress || config.passport.passport.agentId
  const scope = `inference:serve:${request.model}`

  // Verify host
  const check = verifyGonkaHost(host, request.model, config)
  if (!check.authorized) {
    if (config.onDenied) config.onDenied({ host, reason: check.reason })
    const receipt = buildReceipt(config.passport.passport.agentId, config.delegation.delegationId, config.privateKey, request.model, scope, 'failure', check.reason)
    if (config.onReceipt) config.onReceipt(receipt)
    return { denied: true, reason: check.reason, receipt }
  }

  // Rate limit check
  if (config.maxInferencesPerEpoch != null) {
    const key = getEpochKey(config.passport.passport.agentId, request.epochId)
    const count = epochCounters.get(key) || 0
    if (count >= config.maxInferencesPerEpoch) {
      const reason = `Rate limit exceeded: ${count}/${config.maxInferencesPerEpoch} inferences this epoch`
      if (config.onDenied) config.onDenied({ host, reason })
      const receipt = buildReceipt(config.passport.passport.agentId, config.delegation.delegationId, config.privateKey, request.model, scope, 'failure', reason)
      if (config.onReceipt) config.onReceipt(receipt)
      return { denied: true, reason, receipt }
    }
    epochCounters.set(key, count + 1)
  }

  // Execute
  const result = await execute(request)

  // Compute inference hash for devshard verification
  const inferenceHash = sha256(canonicalizeForWrite({ prompt: request.prompt, response: result.response }))

  const receipt = buildReceipt(
    config.passport.passport.agentId, config.delegation.delegationId, config.privateKey,
    request.model, scope, 'success',
    `Inference completed: ${result.tokensUsed} tokens, hash: ${inferenceHash.slice(0, 16)}`,
  )
  if (config.onReceipt) config.onReceipt(receipt)

  return {
    result,
    receipt: { receipt, model: request.model, epochId: request.epochId, devshardId: request.devshardId, inferenceHash },
  }
}

/** Create a devshard session receipt (off-chain proof for settlement) */
export function createDevshardReceipt(
  devshardId: string,
  inferenceCount: number,
  totalTokens: number,
  participants: string[],
  config: Pick<GonkaHostConfig, 'passport' | 'delegation' | 'privateKey'>,
): ActionReceipt {
  const data: Omit<ActionReceipt, 'signature'> = {
    receiptId: `rcpt_devshard_${Date.now().toString(36)}_${Math.random().toString(36).slice(2, 6)}`,
    version: '1.1',
    timestamp: new Date().toISOString(),
    agentId: config.passport.passport.agentId,
    delegationId: config.delegation.delegationId,
    action: {
      type: 'devshard_session',
      target: devshardId,
      scopeUsed: 'devshard:participate',
    },
    result: {
      status: 'success',
      summary: `Devshard ${devshardId}: ${inferenceCount} inferences, ${totalTokens} tokens, ${participants.length} participants`,
    },
    delegationChain: participants,
  }
  const sig = sign(canonicalizeForWrite(data), config.privateKey)
  return { ...data, signature: sig } as ActionReceipt
}

/** Convert APS delegation to Gonka-compatible allowlist entry */
export function delegationToAllowlistEntry(
  delegation: Delegation,
  passport: SignedPassport,
): { address: string; model: string; scope: string[]; expiresAtBlock?: number } {
  const models = delegation.scope
    .filter(s => s.startsWith('inference:serve:'))
    .map(s => s.replace('inference:serve:', ''))

  return {
    address: passport.passport.agentId,
    model: models[0] || '*',
    scope: delegation.scope,
    expiresAtBlock: undefined,
  }
}

/** Convert Gonka epoch timing to APS delegation expiry */
export function epochToDelegationExpiry(
  currentEpoch: number,
  epochDurationBlocks: number,
  epochsValid: number,
): Date {
  // Assume ~6 second block time (Cosmos SDK default)
  const blocksRemaining = epochDurationBlocks * epochsValid
  const secondsRemaining = blocksRemaining * 6
  // The instant is computed here rather than parsed from anything, so the Date
  // is set from that number instead of constructed from an argument. Same
  // returned instant; this file interprets no timestamp string at all.
  const expiresAtMs = Date.now() + secondsRemaining * 1000
  const expiresAt = new Date()
  expiresAt.setTime(expiresAtMs)
  return expiresAt
}

/** Validate PoC (Proof-of-Compute) participation receipt */
export function verifyPoCParticipation(
  hostAddress: string,
  epochId: number,
  weight: number,
  config: Pick<GonkaHostConfig, 'passport' | 'privateKey'>,
): ActionReceipt {
  const data: Omit<ActionReceipt, 'signature'> = {
    receiptId: `rcpt_poc_${Date.now().toString(36)}_${Math.random().toString(36).slice(2, 6)}`,
    version: '1.1',
    timestamp: new Date().toISOString(),
    agentId: config.passport.passport.agentId,
    delegationId: 'poc_validation',
    action: {
      type: 'poc_participation',
      target: hostAddress,
      scopeUsed: 'inference:validate',
    },
    result: {
      status: 'success',
      summary: `PoC validation: host ${hostAddress}, epoch ${epochId}, weight ${weight}`,
    },
    delegationChain: [],
  }
  const sig = sign(canonicalizeForWrite(data), config.privateKey)
  return { ...data, signature: sig } as ActionReceipt
}
