// Copyright (c) 2026 Tymofii Pidlisnyi
// SPDX-License-Identifier: Apache-2.0
/**
 * LangChain Adapter — primitive mappings between LangChain tool calls and APS delegations.
 *
 * Pure mapping + receipt-builder layer. Stateful runtime (pending-intent tracking,
 * audit trail, gateway reporting) lives in the gateway — callers that need those
 * behaviours supply them via the `onReceipt` / `onDenied` hooks.
 */

import { scopeAuthorizes, verifyDelegation, type RevocationCheckOptions } from '../core/delegation.js'
import { checkPassportTrustPosture } from '../verification/trust-posture.js'
import { sign } from '../crypto/keys.js'
import { canonicalize, canonicalizeForWrite } from '../core/canonical.js'
import type { Delegation, ActionReceipt, SignedPassport } from '../types/passport.js'

export interface LangChainToolCall {
  name: string
  args: Record<string, unknown>
  id?: string
}

export interface GovernedToolResult {
  output: unknown
  receipt: ActionReceipt
}

export interface DeniedToolResult {
  denied: true
  reason: string
  receipt: ActionReceipt
}

export interface LangChainGovernanceConfig {
  passport: SignedPassport
  delegation: Delegation
  privateKey: string
  scopeMapping?: Record<string, string>
  onReceipt?: (r: ActionReceipt) => void
  onDenied?: (info: { tool: string; reason: string }) => void
  /** Trust anchors for this gate: issuer public keys whose countersignature
   *  is accepted. A NON-EMPTY list requires a valid countersignature from one
   *  of them. An empty list, or omitting it, means this gate holds no
   *  anchors; it does not mean "trust anyone". */
  trustedIssuers?: string[]
  /** Explicit wildcard trust: admit a passport whose only authority is its
   *  own signature. Required to admit a self-signed credential, because a
   *  signature that verifies under a key the passport itself supplied is not
   *  an authorization by a trusted issuer. Default false. */
  allowSelfSigned?: boolean
  /** Revocation posture applied to the delegation check before every
   *  governed call. This adapter is an execution gate: it verifies the
   *  delegation immediately before the tool runs, which is exactly where a
   *  caller who will not act on unknown revocation state says so. Pass
   *  { revocationCheckPolicy: 'fail_closed', cachedRevocationState } to
   *  refuse when revocation evidence is absent or stale. Omitted leaves the
   *  previous behaviour, signature and expiry only. */
  revocation?: RevocationCheckOptions
}

function buildLCReceipt(
  agentId: string, delegationId: string, privateKey: string,
  toolName: string, scope: string, status: 'success' | 'failure', summary: string,
): ActionReceipt {
  const data: Omit<ActionReceipt, 'signature'> = {
    receiptId: `rcpt_lc_${Date.now().toString(36)}_${Math.random().toString(36).slice(2, 6)}`,
    version: '1.1',
    timestamp: new Date().toISOString(),
    agentId, delegationId,
    action: { type: 'langchain_tool', target: toolName, scopeUsed: scope },
    result: { status, summary },
    delegationChain: [],
  }
  const sig = sign(canonicalizeForWrite(data), privateKey)
  return { ...data, signature: sig } as ActionReceipt
}

/** Map LangChain tool name to APS scope */
export function langchainToolToScope(
  toolName: string,
  scopeMapping?: Record<string, string>,
): string {
  if (scopeMapping && scopeMapping[toolName]) return scopeMapping[toolName]
  return `tools:${toolName}`
}

/** Govern a single LangChain tool call */
export async function governLangChainTool(
  call: LangChainToolCall,
  execute: (args: Record<string, unknown>) => Promise<unknown>,
  config: LangChainGovernanceConfig,
): Promise<GovernedToolResult | DeniedToolResult> {
  const scope = langchainToolToScope(call.name, config.scopeMapping)
  const { passport, delegation, privateKey } = config

  // Passport check
  const pc = checkPassportTrustPosture(passport, config)
  if (!pc.ok) {
    const reason = pc.detail ?? 'Passport rejected at the gate'
    if (config.onDenied) config.onDenied({ tool: call.name, reason })
    const receipt = buildLCReceipt(passport.passport.agentId, delegation.delegationId, privateKey, call.name, scope, 'failure', reason)
    if (config.onReceipt) config.onReceipt(receipt)
    return { denied: true, reason, receipt }
  }

  // Delegation check
  const dc = verifyDelegation(delegation, config.revocation)
  if (!dc.valid) {
    const reason = `Delegation invalid: ${dc.errors.join(', ')}`
    if (config.onDenied) config.onDenied({ tool: call.name, reason })
    const receipt = buildLCReceipt(passport.passport.agentId, delegation.delegationId, privateKey, call.name, scope, 'failure', reason)
    if (config.onReceipt) config.onReceipt(receipt)
    return { denied: true, reason, receipt }
  }

  // Scope check
  if (!scopeAuthorizes(delegation.scope, scope)) {
    const reason = `Scope "${scope}" not covered by delegation [${delegation.scope.join(', ')}]`
    if (config.onDenied) config.onDenied({ tool: call.name, reason })
    const receipt = buildLCReceipt(passport.passport.agentId, delegation.delegationId, privateKey, call.name, scope, 'failure', reason)
    if (config.onReceipt) config.onReceipt(receipt)
    return { denied: true, reason, receipt }
  }

  // Execute
  const output = await execute(call.args)
  const receipt = buildLCReceipt(passport.passport.agentId, delegation.delegationId, privateKey, call.name, scope, 'success', 'Tool executed successfully')
  if (config.onReceipt) config.onReceipt(receipt)
  return { output, receipt }
}

/** Create a governance middleware for LangGraph */
export function createLangGraphGovernance(config: LangChainGovernanceConfig) {
  return (call: LangChainToolCall, execute: (args: Record<string, unknown>) => Promise<unknown>) =>
    governLangChainTool(call, execute, config)
}
