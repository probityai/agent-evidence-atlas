// Copyright (c) 2026 Tymofii Pidlisnyi
// SPDX-License-Identifier: Apache-2.0
// ══════════════════════════════════════════════════════════════════
// Module 37: Decision Semantics & Cross-Engine Interop
// ══════════════════════════════════════════════════════════════════
// Types for content-addressable decisions, evaluation method
// classification, scope interpretation declaration, and
// cross-engine decision artifacts.
//
// Motivated by cross-engine verification work (kanoniv/agent-auth#2):
// four engines evaluating the same scenario produced identical
// structural verdicts but divergent trust verdicts. These types
// formalize the decomposition.
// ══════════════════════════════════════════════════════════════════

import type { PolicyVerdict } from './policy.js'
import type { EvaluationMethod } from './execution-envelope.js'

// Re-export so consumers can get it from either place
export type { EvaluationMethod } from './execution-envelope.js'

// ── Scope Interpretation ──
// Declares how an engine resolves scope membership.
// Exact: literal string equality (data:read ≠ data:*)
// Glob: wildcard expansion (data:* covers data:read)
// Hierarchical: parent:child nesting (data covers data:read)

export type ScopeInterpretation = 'exact' | 'glob' | 'hierarchical'

// ── Evaluation Method ──
// Re-exported from execution-envelope.ts (unified type).
// Values: 'deterministic' | 'probabilistic' | 'model_dependent' | 'hybrid'

// ── Content Hash ──
// Algorithm used for content-addressable hashing of decision artifacts.
// SHA-256 of canonical JSON (unsigned fields only).

export type ContentHashAlgorithm = 'sha256'

export interface ContentHash {
  algorithm: ContentHashAlgorithm
  hash: string              // hex-encoded hash
  canonicalForm: string     // serialization method used (e.g. 'canonical_json_sorted_keys')
  /** Identity boundary: sorted list of top-level field names included in the hash.
   *  Part of the committed content — changing the boundary changes the hash.
   *  Enables portable identity: any engine can verify which fields define identity
   *  without depending on external spec projection rules. */
  identityBoundary?: string[]
}

// ── Decision Semantics ──
// Decomposition of a verdict into structural and trust components.
// Captures the divergence patterns observed across engines.

export interface DecisionSemantics {
  structuralVerdict: PolicyVerdict     // scope/delegation/expiry checks
  trustVerdict: PolicyVerdict | null   // reputation/behavioral checks (null if no trust layer)
  override?: {
    active: boolean
    phase: string                      // mechanism name (e.g. 'threshold_cutoff', 'divergence_alert')
    wouldHaveBeen: PolicyVerdict       // what the verdict would be without the override
  }
  finalVerdictRule: string             // e.g. 'structural AND trust'
  reproducibility: string             // e.g. 'structural_by_any_engine, trust_by_originating_engine_only'
}

// ── Decision Artifact ──
// Cross-engine artifact that bundles an intent, its evaluation,
// and semantic decomposition into a single verifiable object.
// Designed for the cross-engine verification matrix.

export interface DecisionArtifact {
  artifactId: string
  artifactType: 'decision'
  version: string                     // artifact format version
  engine: string                      // producing engine identifier
  timestamp: string

  // The decision itself (pre-execution)
  intent: {
    intentId: string
    agentId: string
    action: {
      type: string
      target: string
      scopeRequired: string
    }
    contentHash: ContentHash          // content-addressable reference
  }

  // How it was evaluated
  evaluation: {
    verdict: PolicyVerdict
    evaluationMethod: EvaluationMethod
    principlesChecked: string[]       // principle IDs evaluated
    evaluatorId: string
    decisionId: string
  }

  // Semantic decomposition for cross-engine comparison
  semantics: DecisionSemantics

  // Cryptographic proof
  proof: {
    intentSignature: string
    decisionSignature: string
    artifactSignature: string         // signature over the entire artifact
  }
}

// ── Verification Result ──

export interface DecisionArtifactVerification {
  /** The conjunction of every property below. True only when the artifact is
   *  bound to the source intent and decision, both were signed by the trust
   *  anchors the caller supplied, and every projected value matches its
   *  source. Never true on the artifact's self-consistency alone. */
  valid: boolean
  /** The artifact's content hash was recomputed from `originalIntent` and
   *  matched. An artifact carrying no content hash is not verifiable and
   *  reports false. */
  contentHashValid: boolean
  /** `originalIntent.signature` verified under `keys.intentSignerPublicKey`
   *  — the caller's anchor, not the key the intent carries about itself. */
  intentSignatureValid: boolean
  /** `originalDecision.signature` verified under
   *  `keys.decisionSignerPublicKey`, on the same terms. */
  decisionSignatureValid: boolean
  /** The artifact envelope verified under `keys.artifactSignerPublicKey`. */
  artifactSignatureValid: boolean
  /** `originalDecision.intentId === originalIntent.intentId`: the decision
   *  presented is a decision about the intent presented. */
  linkageValid: boolean
  /** Every value the artifact projects from the intent or the decision —
   *  verdict, evaluator, decision id, principles, action, hashes and the two
   *  copied signature strings — equals its source. */
  projectionValid: boolean
  errors: string[]
}
