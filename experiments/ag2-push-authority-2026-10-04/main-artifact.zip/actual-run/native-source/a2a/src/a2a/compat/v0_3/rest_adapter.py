import functools
import logging

from collections.abc import AsyncIterable, AsyncIterator, Awaitable, Callable
from typing import TYPE_CHECKING, Any


if TYPE_CHECKING:
    from sse_starlette.sse import EventSourceResponse
    from starlette.requests import Request
    from starlette.responses import JSONResponse, Response

    from a2a.server.context import ServerCallContext
    from a2a.server.request_handlers.request_handler import RequestHandler

    _package_starlette_installed = True
else:
    try:
        from sse_starlette.sse import EventSourceResponse
        from starlette.requests import Request
        from starlette.responses import JSONResponse, Response

        _package_starlette_installed = True
    except ImportError:
        EventSourceResponse = Any
        Request = Any
        JSONResponse = Any
        Response = Any

        _package_starlette_installed = False


from a2a.compat.v0_3.context_builders import V03ServerCallContextBuilder
from a2a.compat.v0_3.rest_handler import REST03Handler
from a2a.server.routes.common import (
    DefaultServerCallContextBuilder,
    ServerCallContextBuilder,
    create_event_source_response,
)
from a2a.utils import json_utils
from a2a.utils.error_handlers import (
    rest_error_handler,
    rest_stream_error_handler,
)
from a2a.utils.errors import (
    InvalidRequestError,
)


logger = logging.getLogger(__name__)


class REST03Adapter:
    """Adapter to make RequestHandler work with v0.3 RESTful API.

    Defines v0.3 REST request processors and their routes, as well as managing response generation including Server-Sent Events (SSE).
    """

    def __init__(
        self,
        http_handler: 'RequestHandler',
        context_builder: 'ServerCallContextBuilder | None' = None,
        shutdown_grace_period: float = 0,
    ) -> None:
        self.handler = REST03Handler(request_handler=http_handler)
        self._context_builder = V03ServerCallContextBuilder(
            context_builder or DefaultServerCallContextBuilder()
        )
        self._shutdown_grace_period = shutdown_grace_period

    @rest_error_handler
    async def _handle_request(
        self,
        method: 'Callable[[Request, ServerCallContext], Awaitable[Any]]',
        request: Request,
    ) -> Response:
        call_context = self._context_builder.build(request)
        response = await method(request, call_context)
        return JSONResponse(content=response)

    @rest_stream_error_handler
    async def _handle_streaming_request(
        self,
        method: 'Callable[[Request, ServerCallContext], AsyncIterable[Any]]',
        request: Request,
    ) -> EventSourceResponse:
        try:
            await request.body()
        except (ValueError, RuntimeError, OSError) as e:
            raise InvalidRequestError(
                message=f'Failed to pre-consume request body: {e}'
            ) from e

        call_context = self._context_builder.build(request)

        async def event_generator(
            stream: AsyncIterable[Any],
        ) -> AsyncIterator[str]:
            async for item in stream:
                yield json_utils.dumps(item)

        return create_event_source_response(
            event_generator(method(request, call_context)),
            shutdown_grace_period=self._shutdown_grace_period,
        )

    def routes(self) -> dict[tuple[str, str], Callable[[Request], Any]]:
        """Constructs a dictionary of API routes and their corresponding handlers."""
        routes: dict[tuple[str, str], Callable[[Request], Any]] = {
            ('/v1/message:send', 'POST'): functools.partial(
                self._handle_request, self.handler.on_message_send
            ),
            ('/v1/message:stream', 'POST'): functools.partial(
                self._handle_streaming_request,
                self.handler.on_message_send_stream,
            ),
            ('/v1/tasks/{id}:cancel', 'POST'): functools.partial(
                self._handle_request, self.handler.on_cancel_task
            ),
            ('/v1/tasks/{id}:subscribe', 'GET'): functools.partial(
                self._handle_streaming_request,
                self.handler.on_subscribe_to_task,
            ),
            ('/v1/tasks/{id}:subscribe', 'POST'): functools.partial(
                self._handle_streaming_request,
                self.handler.on_subscribe_to_task,
            ),
            ('/v1/tasks/{id}', 'GET'): functools.partial(
                self._handle_request, self.handler.on_get_task
            ),
            (
                '/v1/tasks/{id}/pushNotificationConfigs/{push_id}',
                'GET',
            ): functools.partial(
                self._handle_request, self.handler.get_push_notification
            ),
            (
                '/v1/tasks/{id}/pushNotificationConfigs',
                'POST',
            ): functools.partial(
                self._handle_request, self.handler.set_push_notification
            ),
            (
                '/v1/tasks/{id}/pushNotificationConfigs',
                'GET',
            ): functools.partial(
                self._handle_request, self.handler.list_push_notifications
            ),
            # ListTasks is intentionally absent: not in the A2A v0.3 spec (see
            # issue #1043). Sibling v0.3 transports (jsonrpc_transport,
            # grpc_transport, rest_transport) also reject list_tasks with
            # NotImplementedError — do not add a route here.
            ('/v1/card', 'GET'): functools.partial(
                self._handle_request, self.handler.on_get_extended_agent_card
            ),
        }

        return routes
