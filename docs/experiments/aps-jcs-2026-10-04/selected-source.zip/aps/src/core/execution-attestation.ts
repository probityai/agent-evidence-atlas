// Copyright (c) 2026 Tymofii Pidlisnyi
// SPDX-License-Identifier: Apache-2.0
// ══════════════════════════════════════════════════════════════════
// Execution Attestation — Checkpoint 3 Implementation
// ══════════════════════════════════════════════════════════════════
// The missing piece: proof of what was EXECUTED, not just authorized.
//
// Architecture:
//   Checkpoint 1: PolicyReceipt (what was AUTHORIZED)  — already shipped
//   Checkpoint 2: CompoundDigest (binding intent→receipt) — already shipped
//   Checkpoint 3: ExecutionAttestation (what ACTUALLY RAN) — this file
//
// The sandbox/container/runtime calls createExecutionAttestation()
// after tool execution, signing with its own key (not the agent's).
// Verifiers call verifyExecutionAttestation() to check the attestation
// signature and detect drift between intent and execution.
//
// References:
//   - desiorac qntm#6 "Execution Attestation Interface spec v0.1"
//   - QueBallSharken + desiorac OWASP#802 gap identification
//   - agent-morrow authorized_profile_hash pattern (W3C PR #33)
// ══════════════════════════════════════════════════════════════════

import { createHash, randomUUID } from 'node:crypto'
import { sign, verify } from '../crypto/keys.js'
import { canonicalize, canonicalizeForWrite } from './canonical.js'
import { parseRfc3339 } from './rfc3339.js'
import type {
  ExecutionAttestation,
  ExecutionAttestationVerification,
  ExecutionDrift,
  ExecutionDriftSeverity,
  CreateExecutionAttestationInput,
  DriftClassificationRule,
} from '../types/execution-attestation.js'
import { DEFAULT_DRIFT_RULES } from '../types/execution-attestation.js'

// ── SHA-256 helper ──
function sha256(input: string): string {
  return createHash('sha256').update(input).digest('hex')
}

// ══════════════════════════════════════════════════════════════════
// createExecutionAttestation
// ══════════════════════════════════════════════════════════════════
// Called by the sandbox/runtime AFTER tool execution.
// The attestor signs with its own key — the agent cannot forge this.
//
// Flow:
//   1. Hash actual parameters and result
//   2. Hash declared intent parameters
//   3. Compare parameter hashes to detect drift
//   4. Classify drift severity using rules
//   5. Sign the attestation with attestor's key
//
// The two caller-supplied timestamps are checked before anything is signed:
// both must be readable instants, and completion must not precede start.
// verifyExecutionAttestation reads them as instants, so a spelling it cannot
// read fails the timing check permanently: the attestation is signed, immutable
// and unverifiable, and the attestor learns that only when a relying party
// rejects it. Zone-less values are the ordinary way this happens — Python's
// datetime.isoformat() emits one — and a local time names no instant, so there
// is nothing to normalize it into. They are refused here instead, at the one
// moment the caller can still fix the input.
//
// Refusing rather than rewriting is deliberate. No normalization convention
// governs this artifact (the one that exists, normalizeTimestamp in
// core/canonical.ts, governs action_ref preimages), and silently rewriting a
// caller's value into bytes the attestor then signs would put an instant in the
// record that the attestor never wrote.
export function createExecutionAttestation(
  input: CreateExecutionAttestationInput,
  attestorPrivateKey: string,
  opts?: { driftRules?: DriftClassificationRule[]; executionContext?: string }
): ExecutionAttestation {
  const instants: Record<string, number> = {}
  for (const [field, value] of [
    ['executionStartedAt', input.executionStartedAt],
    ['executionCompletedAt', input.executionCompletedAt],
  ] as const) {
    const parsed = parseRfc3339(value)
    if (!parsed.ok) {
      throw new Error(
        `createExecutionAttestation: ${field} must be an RFC 3339 instant ` +
        `(YYYY-MM-DDTHH:MM:SS[.fff](Z|+HH:MM)), got ${JSON.stringify(value)} (${parsed.reason})`,
      )
    }
    instants[field] = parsed.ms
  }

  // The verifier's timing check requires completion at or after start. Minting
  // an attestation that fails it produces the same signed, immutable,
  // permanently unverifiable artifact an unreadable spelling produced, and for
  // the same reason: the attestor learns only when a relying party rejects it.
  // Equal instants are allowed, matching the verifier's `end >= start`.
  if (instants.executionCompletedAt < instants.executionStartedAt) {
    throw new Error(
      'createExecutionAttestation: executionCompletedAt is before executionStartedAt ' +
      `(${JSON.stringify(input.executionStartedAt)} to ` +
      `${JSON.stringify(input.executionCompletedAt)}). An execution cannot complete ` +
      'before it starts, and verifyExecutionAttestation refuses the ordering.',
    )
  }

  const rules = opts?.driftRules ?? DEFAULT_DRIFT_RULES
  const context = opts?.executionContext ?? input.executionContext ?? '*'

  // Hash what actually executed
  const parameterHash = sha256(canonicalizeForWrite(input.actualParameters))
  const resultHash = sha256(canonicalizeForWrite(input.actualResult))

  // Hash what was declared at intent time
  const intentParameterHash = sha256(canonicalizeForWrite(input.intentParameters))

  // Detect drift — always return explicit object, never null
  const match = parameterHash === intentParameterHash
  const drift = match
    ? { fields: [] as ExecutionDrift['fields'], severity: 'none' as const }
    : classifyDrift(input.intentParameters, input.actualParameters, rules, context, input.hashContributingFields)

  const now = new Date().toISOString()

  // Build attestation body (everything except signature)
  const body = {
    executionId: randomUUID(),
    agentId: input.agentId,
    attestorId: input.attestorId,
    attestorType: input.attestorType,
    toolName: input.toolName,
    parameterHash,
    resultHash,
    policyReceiptId: input.policyReceiptId,
    executionFrameId: input.executionFrameId,
    intentParameterHash,
    match,
    drift,
    executionStartedAt: input.executionStartedAt,
    executionCompletedAt: input.executionCompletedAt,
    attestedAt: now,
    ...(input.trust_context ? { trust_context: input.trust_context } : {}),
  }

  // Sign the entire body with the attestor's key
  const canonical = canonicalizeForWrite(body)
  const signature = sign(canonical, attestorPrivateKey)

  return { ...body, signature }
}

// ══════════════════════════════════════════════════════════════════
// verifyExecutionAttestation
// ══════════════════════════════════════════════════════════════════
// Any verifier can check:
//   1. Attestor signature (Ed25519 over canonical body)
//   2. Receipt binding (policyReceiptId + executionFrameId present)
//   3. Parameter match consistency (match flag agrees with hashes)
//   4. Timing sanity (execution completed after it started)
export function verifyExecutionAttestation(
  attestation: ExecutionAttestation,
  attestorPublicKey: string,
  receipt?: { policyReceiptId: string; executionFrameId?: string }
): ExecutionAttestationVerification {
  const errors: string[] = []

  // 1. Verify attestor signature
  const { signature, ...body } = attestation
  const canonical = canonicalize(body)
  const signatureValid = verify(canonical, signature, attestorPublicKey)
  if (!signatureValid) errors.push('Attestor signature invalid')

  // 2. Receipt binding
  let receiptBindingValid = true
  if (receipt) {
    if (attestation.policyReceiptId !== receipt.policyReceiptId) {
      receiptBindingValid = false
      errors.push(`Receipt ID mismatch: attestation=${attestation.policyReceiptId}, receipt=${receipt.policyReceiptId}`)
    }
    if (receipt.executionFrameId && attestation.executionFrameId !== receipt.executionFrameId) {
      receiptBindingValid = false
      errors.push(`Frame ID mismatch: attestation=${attestation.executionFrameId}, receipt=${receipt.executionFrameId}`)
    }
  }

  // 3. Parameter match consistency
  const parameterMatch = attestation.parameterHash === attestation.intentParameterHash
  if (parameterMatch !== attestation.match) {
    errors.push(`Match flag inconsistent: hashes ${parameterMatch ? 'match' : 'differ'} but match=${attestation.match}`)
  }

  // 4. Timing sanity. A timestamp this verifier cannot read states no instant,
  //    so the ordering it would have to satisfy cannot be confirmed and the
  //    check fails — an unreadable clock is never a passing clock.
  const start = parseRfc3339(attestation.executionStartedAt)
  const end = parseRfc3339(attestation.executionCompletedAt)
  const attested = parseRfc3339(attestation.attestedAt)
  let timingValid: boolean
  if (!start.ok || !end.ok || !attested.ok) {
    timingValid = false
    errors.push('Timing invalid: executionStartedAt, executionCompletedAt or attestedAt is not an RFC 3339 instant')
  } else {
    timingValid = end.ms >= start.ms && attested.ms >= start.ms
    if (!timingValid) {
      errors.push('Timing invalid: execution completed before start or attested before start')
    }
  }

  return {
    valid: errors.length === 0,
    signatureValid,
    receiptBindingValid,
    parameterMatch,
    timingValid,
    drift: attestation.drift,
    errors,
  }
}

// ══════════════════════════════════════════════════════════════════
// detectExecutionDrift
// ══════════════════════════════════════════════════════════════════
// Standalone drift detection: given an attestation, return the drift
// analysis. Useful when you already have an attestation and want to
// re-classify drift with different rules.
export function detectExecutionDrift(
  attestation: ExecutionAttestation,
  rules?: DriftClassificationRule[]
): ExecutionDrift {
  return attestation.drift
}

// ══════════════════════════════════════════════════════════════════
// classifyDrift (internal)
// ══════════════════════════════════════════════════════════════════
// Compare intent vs actual parameters field-by-field and classify
// each difference using the drift rules.
function classifyDrift(
  intentParams: Record<string, unknown>,
  actualParams: Record<string, unknown>,
  rules: DriftClassificationRule[],
  context: string = '*',
  hashContributingFields?: string[]
): ExecutionDrift {
  const allKeys = new Set([
    ...Object.keys(intentParams),
    ...Object.keys(actualParams),
  ])

  const driftFields: ExecutionDrift['fields'] = []

  for (const key of allKeys) {
    const intentVal = intentParams[key]
    const actualVal = actualParams[key]
    const intentHash = sha256(canonicalizeForWrite(intentVal ?? null))
    const actualHash = sha256(canonicalizeForWrite(actualVal ?? null))

    if (intentHash !== actualHash) {
      driftFields.push({
        field: key,
        intentValueHash: intentHash,
        executionValueHash: actualHash,
      })
    }
  }

  // Classify severity: highest severity wins
  const severityOrder: ExecutionDriftSeverity[] = ['none', 'benign', 'suspicious', 'critical']
  let maxSeverity: ExecutionDriftSeverity = 'none'

  for (const df of driftFields) {
    // Match on (field, context) pair — context-specific rules take priority
    const rule = rules.find(r => r.field === df.field && r.context === context)
      ?? rules.find(r => r.field === df.field && (!r.context || r.context === '*'))
      ?? rules.find(r => r.field === '*' && r.context === context)
      ?? rules.find(r => r.field === '*' && (!r.context || r.context === '*'))
    const sev = rule?.severity ?? 'suspicious'
    if (severityOrder.indexOf(sev) > severityOrder.indexOf(maxSeverity)) {
      maxSeverity = sev
    }
  }

  // Check if any drifted field contributes to a signed hash (desiorac qntm#6)
  const hashAffected = hashContributingFields
    ? driftFields.some(df => hashContributingFields.includes(df.field))
    : undefined

  return { fields: driftFields, severity: maxSeverity, ...(hashAffected !== undefined ? { hashAffected } : {}) }
}
