// Copyright (c) 2026 Tymofii Pidlisnyi
// SPDX-License-Identifier: Apache-2.0
// ══════════════════════════════════════════════════════════════════
// Values Floor Policy Engine — v1
// ══════════════════════════════════════════════════════════════════
// Three-signature chain: ActionIntent → PolicyDecision → ActionReceipt
//
// v1 validator covers 90% of real attacks:
//   ✓ Agent registered + active (attestation valid)
//   ✓ Delegation non-expired and non-revoked
//   ✓ Action within delegated scope
//   ✓ Spend within limits
//   ✓ Depth within bounds
//
// v2+ can plug in OPA, Cedar, or LLM-based evaluators via the
// PolicyValidator interface. The structure is ready; the engine
// is swappable.
// ══════════════════════════════════════════════════════════════════

import { v4 as uuidv4 } from 'uuid'
import { createHash } from 'crypto'
import { sign, verify } from '../crypto/keys.js'
import { canonicalize, canonicalizeForWrite } from './canonical.js'
import { parseRfc3339 } from './rfc3339.js'
import { scopeAuthorizes } from './delegation.js'
import { computeActionRefForWrite } from './action-ref.js'
import type { EnforcementMode } from '../types/passport.js'
import type {
  ActionIntent, PolicyDecision, PolicyReceipt,
  PolicyValidator, ValidationContext, PolicyEvaluationResult,
  PolicyVerdict, PrincipleEvaluation, EpistemicClaims
} from '../types/policy.js'
import type { ActionReceipt, Delegation } from '../types/passport.js'
import {
  emitDecisionReceipt,
  computeDelegationChainRootForWrite,
  type DecisionReceiptEnvelope,
} from '../decisionReceipt.js'

// ══════════════════════════════════════
// ACTION INTENT — Signature 1 of 3
// ══════════════════════════════════════

/**
 * Agent declares what it wants to do before doing it.
 * This is the "ask" — signed by the requesting agent.
 */
export function createActionIntent(opts: {
  agentId: string
  agentPublicKey: string
  delegationId: string
  action: ActionIntent['action']
  context?: string
  privateKey: string
}): ActionIntent {
  const intent: Omit<ActionIntent, 'signature'> = {
    intentId: 'intent_' + uuidv4().slice(0, 12),
    agentId: opts.agentId,
    agentPublicKey: opts.agentPublicKey,
    delegationId: opts.delegationId,
    action: opts.action,
    // explicit null: keeps the shipped preimage bytes (#101); omission would change signatures
    context: opts.context ?? null,
    createdAt: new Date().toISOString()
  }
  // Content-addressed request identity (A2A#1672)
  intent.actionRef = computeActionRefForWrite(intent)

  const signature = sign(canonicalizeForWrite(intent), opts.privateKey)
  return { ...intent, signature }
}

export function verifyActionIntent(intent: ActionIntent): { valid: boolean; errors: string[] } {
  const errors: string[] = []
  const { signature, ...unsigned } = intent
  if (!verify(canonicalize(unsigned), signature, intent.agentPublicKey)) {
    errors.push('Invalid intent signature')
  }
  if (!intent.agentId) errors.push('Missing agentId')
  if (!intent.delegationId) errors.push('Missing delegationId')
  if (!intent.action?.scopeRequired) errors.push('Missing required scope')
  return { valid: errors.length === 0, errors }
}

// ══════════════════════════════════════
// POLICY DECISION — Signature 2 of 3
// ══════════════════════════════════════

/**
 * Evaluate an intent against the floor using a validator.
 * The evaluator signs the decision — cryptographic proof of
 * what was checked and what was decided.
 */
export function evaluateIntent(opts: {
  intent: ActionIntent
  validator: PolicyValidator
  validationContext: ValidationContext
  evaluatorId: string
  evaluatorPublicKey: string
  evaluatorPrivateKey: string
  decisionTTLMinutes?: number
}): PolicyDecision {
  // First verify the intent signature is valid
  const intentCheck = verifyActionIntent(opts.intent)
  if (!intentCheck.valid) {
    throw new Error(`Invalid intent: ${intentCheck.errors.join(', ')}`)
  }

  // Run the validator
  const result = opts.validator.evaluate(
    // Pass unsigned intent to validator (it doesn't need the signature)
    { ...opts.intent, signature: undefined } as Omit<ActionIntent, 'signature'> & { signature: undefined },
    opts.validationContext
  )

  const now = new Date()
  const expires = new Date()
  expires.setTime(now.getTime())
  expires.setMinutes(expires.getMinutes() + (opts.decisionTTLMinutes ?? 5))

  const decision: Omit<PolicyDecision, 'signature'> = {
    decisionId: 'pdec_' + uuidv4().slice(0, 12),
    intentId: opts.intent.intentId,
    evaluatorId: opts.evaluatorId,
    evaluatorPublicKey: opts.evaluatorPublicKey,
    verdict: result.verdict,
    evaluationMethod: result.evaluationMethod,  // Module 37: how the verdict was computed
    principlesEvaluated: result.principlesEvaluated,
    constraints: result.constraints,
    reason: result.reason,
    floorVersion: opts.validationContext.floorVersion,
    evaluatedAt: now.toISOString(),
    expiresAt: expires.toISOString()
  }

  const signature = sign(canonicalizeForWrite(decision), opts.evaluatorPrivateKey)
  return { ...decision, signature }
}

export function verifyPolicyDecision(
  decision: PolicyDecision
): { valid: boolean; errors: string[] } {
  const errors: string[] = []
  const { signature, ...unsigned } = decision
  if (!verify(canonicalize(unsigned), signature, decision.evaluatorPublicKey)) {
    errors.push('Invalid decision signature')
  }
  const expiry = parseRfc3339(decision.expiresAt)
  if (!expiry.ok) {
    errors.push(`Invalid decision expiresAt (${expiry.reason})`)
  } else if (expiry.ms < Date.now()) {
    errors.push('Policy decision expired')
  }
  if (!decision.intentId) errors.push('Missing intentId')
  return { valid: errors.length === 0, errors }
}

// ══════════════════════════════════════
// POLICY RECEIPT — Links all 3 signatures
// ══════════════════════════════════════

/**
 * After execution, create the policy receipt that links:
 * intent (agent signed) → decision (evaluator signed) → receipt (executor signed)
 *
 * This is the complete audit trail. Any third party can verify
 * all three signatures independently.
 */
export function createPolicyReceipt(opts: {
  intent: ActionIntent
  decision: PolicyDecision
  receipt: ActionReceipt
  verifierPrivateKey: string
  /** v2.3 — ordered root-to-leaf delegation chain.
   *  When supplied, the returned receipt carries delegation_chain_root and
   *  delegation_depth. Optional for v2.2.x back-compat. */
  delegationChain?: Delegation[]
  /** v2.3 — typed epistemic labels for the four claim classes.
   *  When supplied, embedded on the PolicyReceipt and carried into the
   *  parallel Decision Receipt envelope (when emitted). */
  epistemicClaims?: EpistemicClaims
}): PolicyReceipt {
  // Verify the chain links correctly
  if (opts.decision.intentId !== opts.intent.intentId) {
    throw new Error('Decision does not reference this intent')
  }
  if (opts.decision.verdict === 'deny') {
    throw new Error('Cannot create receipt for denied intent')
  }

  const pr: Omit<PolicyReceipt, 'signature'> = {
    policyReceiptId: 'prec_' + uuidv4().slice(0, 12),
    intentId: opts.intent.intentId,
    decisionId: opts.decision.decisionId,
    receiptId: opts.receipt.receiptId,
    chain: {
      intentSignature: opts.intent.signature,
      decisionSignature: opts.decision.signature,
      receiptSignature: opts.receipt.signature
    },
    verifiedAt: new Date().toISOString(),
    // Request identity copied from intent (A2A#1672)
    actionRef: opts.intent.actionRef ?? computeActionRefForWrite(opts.intent)
  }

  // v2.3 — bilateral receipt fields (optional, backward-compatible)
  if (opts.delegationChain && opts.delegationChain.length > 0) {
    pr.delegation_chain_root = computeDelegationChainRootForWrite(opts.delegationChain)
    pr.delegation_depth = opts.delegationChain.length
  }
  if (opts.epistemicClaims) {
    pr.epistemic_claims = opts.epistemicClaims
  }

  const signature = sign(canonicalizeForWrite(pr), opts.verifierPrivateKey)
  return { ...pr, signature }
}

/** v2.3 — emit a PolicyReceipt + parallel in-toto Decision Receipt envelope.
 *
 *  Returns both artifacts so v2.2.x consumers keep working against the
 *  PolicyReceipt while v2.3-aware verifiers (APS-aware sinks, cross-repo
 *  verifiers like @veritasacta/verify) consume the Decision Receipt envelope.
 *
 *  Reference implementation of ENFORCEMENT-TRUST-ANCHOR.md Component A.
 *  This is a protocol primitive — gateway integration happens at the caller
 *  (e.g. @aeoess/gateway's ProxyGateway.emit). */
export function createPolicyReceiptWithDecisionReceipt(opts: {
  intent: ActionIntent
  decision: PolicyDecision
  receipt: ActionReceipt
  verifierPrivateKey: string
  delegationChain: Delegation[]
  epistemicClaims: EpistemicClaims
  policyId: string
  issuerId: string
  signerKeyId: string
}): { policyReceipt: PolicyReceipt; decisionReceipt: DecisionReceiptEnvelope } {
  const policyReceipt = createPolicyReceipt({
    intent: opts.intent,
    decision: opts.decision,
    receipt: opts.receipt,
    verifierPrivateKey: opts.verifierPrivateKey,
    delegationChain: opts.delegationChain,
    epistemicClaims: opts.epistemicClaims,
  })

  const decisionReceipt = emitDecisionReceipt({
    intent: opts.intent,
    decision: opts.decision,
    receipt: opts.receipt,
    delegationChain: opts.delegationChain,
    epistemicClaims: opts.epistemicClaims,
    policyId: opts.policyId,
    signerPrivateKey: opts.verifierPrivateKey,
    signerKeyId: opts.signerKeyId,
    issuerId: opts.issuerId,
  })

  return { policyReceipt, decisionReceipt }
}

/** The three source objects a PolicyReceipt names but does not carry, with
 *  the trust anchor for each. The receipt holds only ids and copies of the
 *  three signature strings (see {@link PolicyReceipt}), so the preimages the
 *  chain signatures were made over are not present in it and cannot be
 *  reconstructed from it. Chain verification therefore takes them from the
 *  relying party, which is also where the three anchors belong. */
export interface PolicyReceiptChainInputs {
  intent: ActionIntent
  decision: PolicyDecision
  receipt: ActionReceipt
  /** Agent whose intent signature this relying party accepts. */
  intentSignerPublicKey: string
  /** Evaluator whose decision signature this relying party accepts. */
  decisionSignerPublicKey: string
  /** Executor whose action-receipt signature this relying party accepts. */
  receiptSignerPublicKey: string
}

export interface PolicyReceiptVerification {
  /** The conjunction of envelope integrity and full-chain verification.
   *  False whenever `chain` was not supplied: a receipt whose chain was never
   *  checked has not been verified, and saying otherwise is the defect this
   *  function had. */
  valid: boolean
  /** The receipt envelope was signed by `verifierPublicKey`. */
  envelopeSignatureValid: boolean
  /** The three inner signatures were verified against the supplied anchors,
   *  over the supplied source objects, and every id links up. */
  chainVerified: boolean
  errors: string[]
}

/**
 * Verify a policy receipt AND the three-signature chain it attests to.
 *
 * SCOPE OF CLAIM.
 *   Establishes, when `valid` is true: the receipt envelope was signed by
 *     `verifierPublicKey`; the intent, decision and action receipt supplied by
 *     the caller were signed by the three anchors the caller supplied; the
 *     decision decides that intent; the receipt records that intent; and the
 *     three signature strings the receipt carries are the signatures on those
 *     three objects.
 *   Does NOT establish: that the four keys are the right ones, that they
 *     belong to four different parties (see the note in
 *     {@link verifyDecisionArtifact} on the same subject), that the action
 *     described actually happened, or that the evaluator was entitled to
 *     permit it.
 *
 * `chain` is required, in the types as well as at runtime. Older callers
 * passed two arguments and received `valid: true` for a receipt whose three
 * inner signature strings were arbitrary non-empty text: the strings were
 * tested for presence, never verified, and the objects they were made over
 * were never seen. An untyped caller that still omits it gets
 * `valid: false` with `chainVerified: false` rather than an exception. A
 * relying party that only wants envelope integrity should say so by name with
 * {@link verifyPolicyReceiptEnvelope}.
 */
export function verifyPolicyReceipt(
  policyReceipt: PolicyReceipt,
  verifierPublicKey: string,
  chain: PolicyReceiptChainInputs
): PolicyReceiptVerification {
  const envelope = verifyPolicyReceiptEnvelope(policyReceipt, verifierPublicKey)
  const errors: string[] = [...envelope.errors]

  if (!chain) {
    errors.push(
      'Chain not verified: the intent, decision and action receipt, and a trust anchor for each, ' +
      'are required. Use verifyPolicyReceiptEnvelope for an envelope-integrity check.'
    )
    return {
      valid: false,
      envelopeSignatureValid: envelope.envelopeSignatureValid,
      chainVerified: false,
      errors
    }
  }

  const chainErrors = policyChainMismatches(policyReceipt, chain)
  errors.push(...chainErrors)

  return {
    valid: errors.length === 0,
    envelopeSignatureValid: envelope.envelopeSignatureValid,
    chainVerified: chainErrors.length === 0,
    errors
  }
}

/**
 * Verify only that the receipt envelope was signed by the given key.
 *
 * SCOPE OF CLAIM.
 *   Establishes: the bytes of this PolicyReceipt were signed by
 *     `verifierPublicKey` and have not been altered since.
 *   Does NOT establish: anything about the intent, decision or action receipt
 *     the envelope names. Their signatures are copied into `chain` as strings
 *     and are not checked here — the objects they were made over are not in
 *     the receipt. Use {@link verifyPolicyReceipt} with chain inputs for that.
 *
 * This is the honest name for what the two-argument call used to do.
 */
export function verifyPolicyReceiptEnvelope(
  policyReceipt: PolicyReceipt,
  verifierPublicKey: string
): { valid: boolean; envelopeSignatureValid: boolean; errors: string[] } {
  const errors: string[] = []
  const { signature, ...unsigned } = policyReceipt
  const envelopeSignatureValid = verify(canonicalize(unsigned), signature, verifierPublicKey)
  if (!envelopeSignatureValid) {
    errors.push('Invalid policy receipt signature')
  }
  return { valid: envelopeSignatureValid, envelopeSignatureValid, errors }
}

/** Verify the three inner signatures against the caller's anchors and check
 *  that every id in the receipt links the objects it names. One entry per
 *  failure; empty means the chain holds. */
function policyChainMismatches(
  policyReceipt: PolicyReceipt,
  chain: PolicyReceiptChainInputs
): string[] {
  const errors: string[] = []
  const { intent, decision, receipt } = chain

  // Each inner signature is verified over its own object, against the anchor
  // the caller named — never against a key the object carries about itself.
  const { signature: intentSig, ...unsignedIntent } = intent
  if (!verify(canonicalize(unsignedIntent), intentSig, chain.intentSignerPublicKey)) {
    errors.push('Intent signature does not verify under the supplied intent signer')
  }
  const { signature: decisionSig, ...unsignedDecision } = decision
  if (!verify(canonicalize(unsignedDecision), decisionSig, chain.decisionSignerPublicKey)) {
    errors.push('Decision signature does not verify under the supplied decision signer')
  }
  const { signature: receiptSig, ...unsignedReceipt } = receipt
  if (!verify(canonicalize(unsignedReceipt), receiptSig, chain.receiptSignerPublicKey)) {
    errors.push('Action receipt signature does not verify under the supplied receipt signer')
  }

  // The signature strings the receipt copied must be the signatures on those
  // objects. Without this a receipt could carry three real signatures taken
  // from some other chain.
  if (policyReceipt.chain.intentSignature !== intentSig) {
    errors.push('Receipt carries an intent signature that is not the supplied intent\'s')
  }
  if (policyReceipt.chain.decisionSignature !== decisionSig) {
    errors.push('Receipt carries a decision signature that is not the supplied decision\'s')
  }
  if (policyReceipt.chain.receiptSignature !== receiptSig) {
    errors.push('Receipt carries an action-receipt signature that is not the supplied receipt\'s')
  }

  // Linkage. Each id must name the object presented for it, and the decision
  // must decide the intent presented rather than some other one.
  if (policyReceipt.intentId !== intent.intentId) {
    errors.push('Receipt intentId does not name the supplied intent')
  }
  if (policyReceipt.decisionId !== decision.decisionId) {
    errors.push('Receipt decisionId does not name the supplied decision')
  }
  if (policyReceipt.receiptId !== receipt.receiptId) {
    errors.push('Receipt receiptId does not name the supplied action receipt')
  }
  if (decision.intentId !== intent.intentId) {
    errors.push('Decision does not decide the supplied intent: intentId mismatch')
  }

  // A receipt is proof of a permitted action. A denied decision has no
  // receipt to attest to; createPolicyReceipt refuses to build one, and a
  // verifier must refuse to accept one built another way.
  if (decision.verdict === 'deny') {
    errors.push('Receipt attests to a denied decision')
  }

  const expiry = parseRfc3339(decision.expiresAt)
  if (!expiry.ok) {
    errors.push(`Invalid decision expiresAt (${expiry.reason})`)
  }

  return errors
}

// ══════════════════════════════════════
// V1 VALIDATOR — The Simple Engine
// ══════════════════════════════════════
// Covers 90% of real attacks without building an AI:
//   ✓ Agent registered + attestation valid
//   ✓ Delegation non-expired, non-revoked
//   ✓ Action within delegated scope
//   ✓ Spend within limits
//   ✓ Depth within bounds
//
// This is pluggable via PolicyValidator interface.
// v2 can swap in OPA, Cedar, or LLM-based evaluators.

export class FloorValidatorV1 implements PolicyValidator {
  readonly version = '1.0'
  readonly name = 'floor-validator-v1'

  evaluate(
    intent: Omit<ActionIntent, 'signature'>,
    ctx: ValidationContext
  ): PolicyEvaluationResult {
    const evals: PrincipleEvaluation[] = []
    const auditFindings: PrincipleEvaluation[] = []
    const warnings: PrincipleEvaluation[] = []
    let dominated: PolicyVerdict = 'permit'
    const constraints: string[] = []
    const reasons: string[] = []

    // Helper: look up enforcement mode for a principle from context
    const getMode = (principleId: string): EnforcementMode => {
      const p = ctx.floorPrinciples?.find(fp => fp.id === principleId)
      if (p?.enforcement?.mode) return p.enforcement.mode
      // Backward compat: technical: true → inline, false → audit
      if (p?.enforcement?.technical === true) return 'inline'
      if (p?.enforcement?.technical === false) return 'audit'
      // Default: F-001 through F-005 → inline, F-006/F-007 → audit
      const num = parseInt(principleId.replace('F-', ''), 10)
      return num <= 5 ? 'inline' : 'audit'
    }

    // Helper: handle a check result based on enforcement mode
    const handleResult = (eval_: PrincipleEvaluation) => {
      const mode = getMode(eval_.principleId)
      eval_.enforcementMode = mode
      evals.push(eval_)

      if (eval_.status === 'fail') {
        switch (mode) {
          case 'inline':
            // Hard failure — will deny
            reasons.push(`${eval_.principleName}: ${eval_.detail}`)
            break
          case 'audit':
            // Logged for human review — action proceeds
            auditFindings.push(eval_)
            break
          case 'warn':
            // Surfaced immediately — action proceeds
            warnings.push(eval_)
            break
        }
      }
    }

    // F-001: Traceability — is the agent registered?
    handleResult(this.checkTraceability(ctx))

    // F-002: Honest Identity — valid attestation?
    handleResult(this.checkIdentity(ctx))

    // F-003: Scoped Authority — action within scope?
    handleResult(this.checkScope(intent, ctx))

    // F-004: Revocability — delegation not revoked?
    handleResult(this.checkRevocability(ctx))

    // F-005: Auditability — delegation not expired, depth ok?
    handleResult(this.checkAuditability(ctx))

    // F-006: Non-Deception — v1 can't check this technically
    const f006Mode = getMode('F-006')
    evals.push({
      principleId: 'F-006', principleName: 'Non-Deception',
      status: 'not_applicable',
      detail: 'Requires reasoning-level evaluation (v2+)',
      enforcementMode: f006Mode,
      layer: 'trust'
    })

    // F-007: Proportionality — v1 can't check this technically
    const f007Mode = getMode('F-007')
    evals.push({
      principleId: 'F-007', principleName: 'Proportionality',
      status: 'not_applicable',
      detail: 'Requires reputation context (v2+)',
      enforcementMode: f007Mode,
      layer: 'trust'
    })

    // Check spend — if over limit, narrow instead of deny
    const spendCheck = this.checkSpend(intent, ctx)
    if (spendCheck) {
      if (spendCheck.verdict === 'narrow') {
        dominated = 'narrow'
        constraints.push(spendCheck.constraint!)
        reasons.push(spendCheck.reason)
      } else if (spendCheck.verdict === 'deny') {
        dominated = 'deny'
        reasons.push(spendCheck.reason)
      }
    }

    // Any inline failure → deny (only inline failures block)
    const inlineFailures = evals.filter(
      e => e.status === 'fail' && e.enforcementMode === 'inline'
    )
    if (inlineFailures.length > 0) {
      dominated = 'deny'
    }

    return {
      verdict: dominated,
      evaluationMethod: 'deterministic' as const,  // Module 37: V1 checks are all reproducible
      principlesEvaluated: evals,
      constraints: constraints.length > 0 ? constraints : undefined,
      reason: reasons.length > 0
        ? reasons.join('; ')
        : auditFindings.length > 0
          ? `Permitted with ${auditFindings.length} audit finding(s)`
          : warnings.length > 0
            ? `Permitted with ${warnings.length} warning(s)`
            : 'All checks passed',
      // Graduated enforcement output
      auditFindings: auditFindings.length > 0 ? auditFindings : undefined,
      warnings: warnings.length > 0 ? warnings : undefined,
      enforcement: {
        inlinePassed: inlineFailures.length === 0,
        auditIssueCount: auditFindings.length,
        warningCount: warnings.length
      }
    }
  }

  private checkTraceability(ctx: ValidationContext): PrincipleEvaluation {
    if (!ctx.agentRegistered) {
      return {
        principleId: 'F-001', principleName: 'Traceability',
        status: 'fail', detail: 'Agent not registered in protocol',
        layer: 'structural'
      }
    }
    return {
      principleId: 'F-001', principleName: 'Traceability',
      status: 'pass', detail: 'Agent registered and traceable',
      layer: 'structural'
    }
  }

  private checkIdentity(ctx: ValidationContext): PrincipleEvaluation {
    if (!ctx.agentAttestationValid) {
      return {
        principleId: 'F-002', principleName: 'Honest Identity',
        status: 'fail', detail: 'Agent attestation invalid or expired',
        layer: 'structural'
      }
    }
    return {
      principleId: 'F-002', principleName: 'Honest Identity',
      status: 'pass', detail: 'Attestation verified',
      layer: 'structural'
    }
  }

  private checkScope(
    intent: Omit<ActionIntent, 'signature'>,
    ctx: ValidationContext
  ): PrincipleEvaluation {
    if (!scopeAuthorizes(ctx.delegation.scope, intent.action.scopeRequired)) {
      return {
        principleId: 'F-003', principleName: 'Scoped Authority',
        status: 'fail',
        detail: `Scope '${intent.action.scopeRequired}' not in delegation [${ctx.delegation.scope.join(', ')}]`,
        layer: 'structural'
      }
    }
    return {
      principleId: 'F-003', principleName: 'Scoped Authority',
      status: 'pass', detail: `Scope '${intent.action.scopeRequired}' authorized`,
      layer: 'structural'
    }
  }

  private checkRevocability(ctx: ValidationContext): PrincipleEvaluation {
    if (ctx.delegation.revoked) {
      return {
        principleId: 'F-004', principleName: 'Revocability',
        status: 'fail', detail: 'Delegation has been revoked',
        layer: 'structural'
      }
    }
    return {
      principleId: 'F-004', principleName: 'Revocability',
      status: 'pass', detail: 'Delegation active',
      layer: 'structural'
    }
  }

  private checkAuditability(ctx: ValidationContext): PrincipleEvaluation {
    const reasons: string[] = []
    const delegationExpiry = parseRfc3339(ctx.delegation.expiresAt)
    if (!delegationExpiry.ok) {
      reasons.push(`Invalid delegation expiresAt (${delegationExpiry.reason})`)
    } else if (delegationExpiry.ms < Date.now()) {
      reasons.push('Delegation expired')
    }
    if (ctx.delegation.currentDepth > ctx.delegation.maxDepth) {
      reasons.push('Depth limit exceeded')
    }
    if (reasons.length > 0) {
      return {
        principleId: 'F-005', principleName: 'Auditability',
        status: 'fail', detail: reasons.join(', '),
        layer: 'structural'
      }
    }
    return {
      principleId: 'F-005', principleName: 'Auditability',
      status: 'pass', detail: 'Delegation valid and within depth limits',
      layer: 'structural'
    }
  }

  private checkSpend(
    intent: Omit<ActionIntent, 'signature'>,
    ctx: ValidationContext
  ): { verdict: PolicyVerdict; reason: string; constraint?: string } | null {
    if (!intent.action.spend) return null
    const limit = ctx.delegation.spendLimit
    if (limit === undefined) return null
    const remaining = limit - (ctx.delegation.spentAmount ?? 0)
    if (intent.action.spend.amount > remaining) {
      if (remaining > 0) {
        return {
          verdict: 'narrow',
          reason: `Spend ${intent.action.spend.amount} exceeds remaining ${remaining}`,
          constraint: `max_spend:${remaining}`
        }
      }
      return {
        verdict: 'deny',
        reason: `No spend budget remaining (limit: ${limit}, spent: ${ctx.delegation.spentAmount ?? 0})`
      }
    }
    return null
  }
}

// ══════════════════════════════════════
// CONVENIENCE — Full chain in one call
// ══════════════════════════════════════

/**
 * Execute the full three-signature chain:
 * 1. Create ActionIntent (agent signs)
 * 2. Evaluate against floor (evaluator signs)
 * 3. If permitted, return the decision for the caller to proceed
 *
 * The ActionReceipt is created separately after execution
 * (by the existing createReceipt function), then linked via
 * createPolicyReceipt.
 */
export function requestAction(opts: {
  agentId: string
  agentPublicKey: string
  agentPrivateKey: string
  delegationId: string
  action: ActionIntent['action']
  context?: string
  validator: PolicyValidator
  validationContext: ValidationContext
  evaluatorId: string
  evaluatorPublicKey: string
  evaluatorPrivateKey: string
}): { intent: ActionIntent; decision: PolicyDecision } {
  const intent = createActionIntent({
    agentId: opts.agentId,
    agentPublicKey: opts.agentPublicKey,
    delegationId: opts.delegationId,
    action: opts.action,
    context: opts.context,
    privateKey: opts.agentPrivateKey
  })

  const decision = evaluateIntent({
    intent,
    validator: opts.validator,
    validationContext: opts.validationContext,
    evaluatorId: opts.evaluatorId,
    evaluatorPublicKey: opts.evaluatorPublicKey,
    evaluatorPrivateKey: opts.evaluatorPrivateKey
  })

  return { intent, decision }
}


// ══════════════════════════════════════════════════════════════════
// Compound Digest & Routing Divergence Detection
// From desiorac on A2A#1672 (compound digest) and OATR#2 (divergence)
// ══════════════════════════════════════════════════════════════════

function sha256(input: string): string {
  return createHash('sha256').update(input).digest('hex')
}

/**
 * Compute a compound digest binding ActionIntent + PolicyReceipt + executionFrameId.
 * A third party can verify the binding from this single value without retrieving
 * both artifacts separately. (desiorac, A2A#1672)
 */
export function computeCompoundDigest(opts: {
  intent: ActionIntent
  receipt: PolicyReceipt
  executionFrameId: string
  timestamp: string
}): string {
  const intentHash = sha256(canonicalize(opts.intent))
  const receiptHash = sha256(canonicalize(opts.receipt))
  return sha256(`${intentHash}+${receiptHash}+${opts.executionFrameId}+${opts.timestamp}`)
}

/**
 * Capture routing context at a point in time. Use at intent declaration time
 * and at execution time. Compare the two with detectRoutingDivergence().
 */
export function captureRoutingContext(opts: {
  did?: string
  didDocument?: string | Record<string, unknown>
  endpoint?: string
}): { did?: string; didDocumentHash?: string; endpointHash?: string } {
  return {
    did: opts.did,
    didDocumentHash: opts.didDocument
      ? sha256(typeof opts.didDocument === 'string' ? opts.didDocument : JSON.stringify(opts.didDocument))
      : undefined,
    endpointHash: opts.endpoint ? sha256(opts.endpoint) : undefined,
  }
}

export type DivergencePattern =
  | 'none'                    // all fields match
  | 'endpoint_migration'      // DID stable, document stable, endpoint changed (benign)
  | 'key_rotation'            // DID stable, endpoint stable, document changed (needs re-attestation)
  | 'full_migration'          // DID stable, document changed, endpoint changed
  | 'entity_change'           // DID changed (always flag)
  | 'partial'                 // some fields diverged, doesn't match a known pattern

/**
 * Detect routing divergence between intent time and execution time.
 * Returns a structured report with the divergence pattern and details.
 * Three distinct patterns (desiorac, OATR#2):
 * 1. DID stable + endpoint changed + doc stable = operational migration (benign)
 * 2. DID stable + endpoint stable + doc changed = key rotation (re-attest)
 * 3. DID changed = different entity (always flag)
 */
export function detectRoutingDivergence(opts: {
  intent: { did?: string; didDocumentHash?: string; endpointHash?: string }
  execution: { did?: string; didDocumentHash?: string; endpointHash?: string }
  resolutionDeltaMs?: number
}): {
  pattern: DivergencePattern
  didChanged: boolean
  documentChanged: boolean
  endpointChanged: boolean
  resolutionDeltaMs?: number
  riskLevel: 'none' | 'low' | 'medium' | 'high'
} {
  const didChanged = opts.intent.did !== opts.execution.did
  const docChanged = opts.intent.didDocumentHash !== opts.execution.didDocumentHash
  const endChanged = opts.intent.endpointHash !== opts.execution.endpointHash

  // If nothing provided, no divergence detectable
  if (!opts.intent.did && !opts.intent.didDocumentHash && !opts.intent.endpointHash) {
    return { pattern: 'none', didChanged: false, documentChanged: false, endpointChanged: false, resolutionDeltaMs: opts.resolutionDeltaMs, riskLevel: 'none' }
  }

  const base = { didChanged, documentChanged: docChanged, endpointChanged: endChanged, resolutionDeltaMs: opts.resolutionDeltaMs }

  // No divergence
  if (!didChanged && !docChanged && !endChanged) {
    return { ...base, pattern: 'none', riskLevel: 'none' }
  }

  // DID changed — different entity entirely (always flag)
  if (didChanged) {
    return { ...base, pattern: 'entity_change', riskLevel: 'high' }
  }

  // DID stable, document changed, endpoint changed — full migration
  if (docChanged && endChanged) {
    return { ...base, pattern: 'full_migration', riskLevel: 'medium' }
  }

  // DID stable, document changed, endpoint stable — key rotation
  if (docChanged && !endChanged) {
    return { ...base, pattern: 'key_rotation', riskLevel: 'medium' }
  }

  // DID stable, document stable, endpoint changed — operational migration (benign)
  if (!docChanged && endChanged) {
    return { ...base, pattern: 'endpoint_migration', riskLevel: 'low' }
  }

  return { ...base, pattern: 'partial', riskLevel: 'medium' }
}


// ══════════════════════════════════════════════════════════════════
// Policy Hash Chaining — Tamper-evident constraint state history
// From haroldmalikfrimpong-ops on A2A#1672 / qntm#7
//
// Every policy evaluation chains the agent's constraint state:
//   policy_hash[N] = SHA-256(constraints_at_N + previous_policy_hash)
//
// If constraints drift through summarization, memory compaction,
// or any mutation — the chain breaks. A verifier can check integrity
// without seeing every evaluation, just by replaying the chain.
// ══════════════════════════════════════════════════════════════════

export interface PolicyChainEntry {
  /** Position in the chain (0-indexed) */
  index: number
  /** The agent this chain belongs to */
  agentId: string
  /** SHA-256(canonicalized constraints + previousHash) */
  policyHash: string
  /** Previous entry's hash (null for genesis) */
  previousPolicyHash: string | null
  /** The constraint snapshot that produced this hash */
  constraints: PolicyConstraintSnapshot
  /** When this entry was created */
  timestamp: string
  /** Optional: which policy evaluation triggered this entry */
  decisionId?: string
}

export interface PolicyConstraintSnapshot {
  /** Active delegation scopes */
  scopes: string[]
  /** Spend limit remaining */
  spendLimit?: number
  /** Trust level / passport grade */
  trustLevel?: number
  /** Max delegation depth remaining */
  maxDepth?: number
  /** Expiry timestamp of active delegation */
  expiresAt?: string
  /** Reversibility ceiling */
  maxReversibility?: string
  /** Any additional constraint dimensions */
  [key: string]: unknown
}

export interface PolicyChain {
  agentId: string
  entries: PolicyChainEntry[]
  currentHash: string | null
}

/**
 * Create a new empty policy chain for an agent.
 */
export function createPolicyChain(agentId: string): PolicyChain {
  return { agentId, entries: [], currentHash: null }
}

/**
 * Append a new constraint snapshot to the chain.
 * Returns the new entry with its computed hash.
 */
export function appendPolicyChainEntry(
  chain: PolicyChain,
  constraints: PolicyConstraintSnapshot,
  decisionId?: string,
): PolicyChainEntry {
  const previousHash = chain.currentHash
  const hashInput = JSON.stringify({
    constraints: canonicalizeForWrite(constraints),
    previousPolicyHash: previousHash,
  })
  const policyHash = sha256(hashInput)

  const entry: PolicyChainEntry = {
    index: chain.entries.length,
    agentId: chain.agentId,
    policyHash,
    previousPolicyHash: previousHash,
    constraints,
    timestamp: new Date().toISOString(),
    decisionId,
  }

  chain.entries.push(entry)
  chain.currentHash = policyHash
  return entry
}

/**
 * Verify the integrity of a policy chain.
 * Recomputes every hash from the constraint snapshots.
 * If any entry was tampered with (constraints changed, entry removed/inserted),
 * the chain breaks and verification fails.
 */
export function verifyPolicyChain(chain: PolicyChain): {
  valid: boolean
  brokenAt?: number
  expectedHash?: string
  actualHash?: string
  length: number
} {
  let previousHash: string | null = null

  for (let i = 0; i < chain.entries.length; i++) {
    const entry = chain.entries[i]

    // Check back-link
    if (entry.previousPolicyHash !== previousHash) {
      return { valid: false, brokenAt: i, expectedHash: previousHash || 'null', actualHash: entry.previousPolicyHash || 'null', length: chain.entries.length }
    }

    // Recompute hash
    const hashInput = JSON.stringify({
      constraints: canonicalize(entry.constraints),
      previousPolicyHash: previousHash,
    })
    const expected = sha256(hashInput)

    if (entry.policyHash !== expected) {
      return { valid: false, brokenAt: i, expectedHash: expected, actualHash: entry.policyHash, length: chain.entries.length }
    }

    previousHash = entry.policyHash
  }

  return { valid: true, length: chain.entries.length }
}

/**
 * Detect constraint drift between consecutive chain entries.
 * Returns which constraint dimensions changed and whether the change
 * was a narrowing (safe) or widening (violation).
 */
export function detectConstraintDrift(chain: PolicyChain): {
  drifts: Array<{
    fromIndex: number
    toIndex: number
    field: string
    before: unknown
    after: unknown
    direction: 'narrowed' | 'widened' | 'changed'
  }>
  hasDrift: boolean
  hasWidening: boolean
} {
  const drifts: Array<{
    fromIndex: number; toIndex: number; field: string
    before: unknown; after: unknown; direction: 'narrowed' | 'widened' | 'changed'
  }> = []

  for (let i = 1; i < chain.entries.length; i++) {
    const prev = chain.entries[i - 1].constraints
    const curr = chain.entries[i].constraints
    const allKeys = new Set([...Object.keys(prev), ...Object.keys(curr)])

    for (const key of allKeys) {
      const before = prev[key]
      const after = curr[key]
      if (JSON.stringify(before) === JSON.stringify(after)) continue

      let direction: 'narrowed' | 'widened' | 'changed' = 'changed'
      if (key === 'scopes' && Array.isArray(before) && Array.isArray(after)) {
        direction = after.length <= before.length && after.every((s: string) => (before as string[]).includes(s)) ? 'narrowed' : 'widened'
      } else if (key === 'spendLimit' && typeof before === 'number' && typeof after === 'number') {
        direction = after <= before ? 'narrowed' : 'widened'
      } else if (key === 'maxDepth' && typeof before === 'number' && typeof after === 'number') {
        direction = after <= before ? 'narrowed' : 'widened'
      } else if (key === 'trustLevel' && typeof before === 'number' && typeof after === 'number') {
        direction = after >= before ? 'narrowed' : 'widened'  // higher trust = more restrictive gate
      }

      drifts.push({ fromIndex: i - 1, toIndex: i, field: key, before, after, direction })
    }
  }

  return {
    drifts,
    hasDrift: drifts.length > 0,
    hasWidening: drifts.some(d => d.direction === 'widened'),
  }
}
