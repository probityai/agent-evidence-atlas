#!/usr/bin/env node
// Copyright (c) 2026 Tymofii Pidlisnyi
// SPDX-License-Identifier: Apache-2.0
// ══════════════════════════════════════════════════════════════
// Agent Social Contract — CLI
// ══════════════════════════════════════════════════════════════
//
// passport join     — Create an agent in the social contract
// passport register — Register agent in the public Agora registry
// passport verify   — Verify an agent's passport + attestation
// passport delegate — Grant authority to another agent
// passport work     — Record a unit of work
// passport prove    — Generate contribution proofs
// passport audit    — Check compliance against the Floor
// passport inspect  — View passport/receipt/proof details
// passport status   — Show current agent status
//
// Data is stored in .passport/ directory:
//   .passport/agent.json     — passport + keys + attestation
//   .passport/delegations/   — active delegations
//   .passport/receipts/      — signed action receipts
//   .passport/proofs/        — generated proofs

import { readFileSync, writeFileSync, mkdirSync, existsSync, readdirSync, chmodSync } from 'node:fs'
import { join } from 'node:path'
import { execSync, execFileSync } from 'node:child_process'
import { createInterface } from 'node:readline'

import {
  joinSocialContract, verifySocialContract,
  delegate, recordWork, proveContributions, auditCompliance,
  generateKeyPair, loadFloor, verifyMerkleProof,
  verifyPassport, verifyAttestation,
  scopeAuthorizes,
  createAgoraMessage, verifyAgoraMessage,
  createFeed, appendToFeed, getThread, getByTopic, getTopics,
  createRegistry, registerAgent, verifyFeed,
  RegulatedActionV0
} from '../index.js'

// Direct module import: src/index.ts export lines are a single-writer
// item deferred to T9 (FREEZE-VWE F8), so verify-bundle does not go
// through the barrel.
import { verifyEvidenceBundle, computeClaimBoundaryReport } from '../core/evidence-bundle.js'
import type { EvidenceBundle, ClaimState } from '../types/evidence-bundle.js'

import type {
  SignedPassport, FloorAttestation,
  ActionReceipt, Delegation, KeyPair,
  AgoraFeed, AgoraRegistry
} from '../index.js'


// ── Paths ──
const DIR = '.passport'
const AGENT_FILE = join(DIR, 'agent.json')
const DEL_DIR = join(DIR, 'delegations')
const RECEIPT_DIR = join(DIR, 'receipts')
const PROOF_DIR = join(DIR, 'proofs')
const AGORA_DIR = join(DIR, 'agora')
const FEED_FILE = join(AGORA_DIR, 'messages.json')
const REGISTRY_FILE = join(AGORA_DIR, 'agents.json')
const AGORA_REPO_OWNER = 'aeoess'
const AGORA_REPO_NAME = 'aeoess_web'

// ── Storage helpers ──

function ensureDirs(): void {
  for (const d of [DIR, DEL_DIR, RECEIPT_DIR, PROOF_DIR]) {
    if (!existsSync(d)) mkdirSync(d, { recursive: true })
  }
}

function saveJSON(path: string, data: unknown): void {
  writeFileSync(path, JSON.stringify(data, null, 2))
  // Restrict file permissions to owner only (private keys may be in the data)
  try { chmodSync(path, 0o600) } catch { /* Windows no-op */ }
}

function loadJSON<T>(path: string): T {
  return JSON.parse(readFileSync(path, 'utf8')) as T
}

function agentExists(): boolean {
  return existsSync(AGENT_FILE)
}

interface StoredAgent {
  passport: SignedPassport
  keyPair: KeyPair
  attestation: FloorAttestation | null
  agentId: string
  publicKey: string
}

function loadAgent(): StoredAgent {
  if (!agentExists()) {
    console.error('❌ No agent found. Run: passport join')
    process.exit(1)
  }
  return loadJSON<StoredAgent>(AGENT_FILE)
}

function loadDelegations(): Delegation[] {
  if (!existsSync(DEL_DIR)) return []
  return readdirSync(DEL_DIR)
    .filter(f => f.endsWith('.json'))
    .map(f => loadJSON<Delegation>(join(DEL_DIR, f)))
}

function loadReceipts(): ActionReceipt[] {
  if (!existsSync(RECEIPT_DIR)) return []
  return readdirSync(RECEIPT_DIR)
    .filter(f => f.endsWith('.json'))
    .map(f => loadJSON<ActionReceipt>(join(RECEIPT_DIR, f)))
}

function askYesNo(question: string): Promise<boolean> {
  const rl = createInterface({ input: process.stdin, output: process.stdout })
  return new Promise(resolve => {
    rl.question(question, answer => {
      rl.close()
      resolve(answer.trim().toLowerCase() !== 'n')
    })
  })
}

// ── CLI Router ──

const args = process.argv.slice(2)

// Canonical decimal only: an optional minus, digits, and an optional fractional part.
// This rejects hexadecimal, octal and binary literals, exponent form, a leading plus,
// surrounding whitespace, and a bare leading or trailing dot. `0x64` reads as
// sixty-four to a human and to every base-10 parser while Number() evaluates it to one
// hundred, and these flags carry authority, so an ambiguity that large is not accepted.
// Declared here, above the command dispatch below, because a `const` is not hoisted and
// the dispatch calls the command functions during module evaluation.
const CANONICAL_DECIMAL = /^-?[0-9]+(?:\.[0-9]+)?$/
const command = args[0]

switch (command) {
  case 'join': cmdJoin(); break
  case 'register': cmdRegister(); break
  case 'verify': cmdVerify(); break
  case 'delegate': cmdDelegate(); break
  case 'work': cmdWork(); break
  case 'prove': cmdProve(); break
  case 'audit': cmdAudit(); break
  case 'inspect': cmdInspect(); break
  case 'status': cmdStatus(); break
  case 'agora': cmdAgora(); break
  case 'verify-regulated': cmdVerifyRegulated(); break
  case 'verify-bundle': cmdVerifyBundle(); break
  default: cmdHelp(); break
}

// ══════════════════════════════════════
// VERIFY-REGULATED: APS Regulated Action Profile v0 disposition
// ══════════════════════════════════════
//
//   agent-passport verify-regulated --receipt <receipt.json> --context <context.json>
//
// Runs the deterministic, stateless disposition verifier over a RegulatedActionReceiptV0
// and a caller-supplied VerificationContext. Prints the disposition, violations, computed
// trust-domain separation, authority basis, and judgment_correctness (always not_claimed).
// Exit code 0 if the disposition is reconciled or regulator_grade_for_class, else 2.

function cmdVerifyRegulated(): void {
  const receiptPath = getFlag('--receipt')
  const contextPath = getFlag('--context')
  if (!receiptPath || !contextPath) {
    console.error('Usage: agent-passport verify-regulated --receipt <receipt.json> --context <context.json>')
    process.exit(1)
  }
  let receipt: Parameters<typeof RegulatedActionV0.verifyRegulatedAction>[0]
  let context: Parameters<typeof RegulatedActionV0.verifyRegulatedAction>[1]
  try {
    receipt = JSON.parse(readFileSync(receiptPath, 'utf8'))
    context = JSON.parse(readFileSync(contextPath, 'utf8'))
  } catch (e) {
    console.error(`Failed to read inputs: ${e instanceof Error ? e.message : String(e)}`)
    process.exit(1)
  }
  const result = RegulatedActionV0.verifyRegulatedAction(receipt, context)
  console.log(JSON.stringify(result, null, 2))
  const final = result.disposition === 'reconciled' || result.disposition === 'regulator_grade_for_class'
  process.exit(final ? 0 : 2)
}

// ══════════════════════════════════════
// VERIFY-BUNDLE: evidence bundle claim-boundary report
// ══════════════════════════════════════
//
//   agent-passport verify-bundle <bundle.json> [--json] [--strict]
//
// Verifies an aps:evidence-bundle:v1 file (manifest signature, Merkle
// root, member digests, inclusion proofs) and prints a per-axis
// ClaimState report over authority, action, revocation and evidence,
// per the SCHEMAS-DRAFT 3d mapping. States are computed from the
// members present; what cannot be computed is reported MISSING or
// UNKNOWN, never assumed.

const VERIFY_BUNDLE_USAGE = `Usage: passport verify-bundle <bundle.json> [--json] [--strict]

  Verifies an evidence bundle (aps:evidence-bundle:v1) and prints a
  per-axis claim report: authority, action, revocation, evidence.

  --json     Emit one JSON object: {axes, overall, exit_reason}
  --strict   Treat MISSING authority or evidence as failure (exit 2)

  Exit codes: 0 report produced, no axis INVALID
              2 any axis INVALID, or --strict with MISSING
                authority or evidence
              3 bundle unreadable or manifest signature failed`

function emitBundleReport(
  jsonMode: boolean,
  axes: Record<'authority' | 'action' | 'revocation' | 'evidence', { state: ClaimState, detail: string }>,
  overall: ClaimState,
  exitReason: string,
): void {
  if (jsonMode) {
    console.log(JSON.stringify({
      axes: {
        authority: axes.authority.state,
        action: axes.action.state,
        revocation: axes.revocation.state,
        evidence: axes.evidence.state,
      },
      overall,
      exit_reason: exitReason,
    }, null, 2))
    return
  }
  console.log('')
  console.log('📦 Evidence Bundle Claim Report')
  for (const axis of ['authority', 'action', 'revocation', 'evidence'] as const) {
    console.log(`  ${axis.padEnd(11)} ${axes[axis].state}`)
    console.log(`     ${axes[axis].detail}`)
  }
  console.log(`  Overall: ${overall}`)
  console.log('')
}

function cmdVerifyBundle(): void {
  const file = args[1]
  const jsonMode = args.includes('--json')
  const strict = args.includes('--strict')
  if (!file || file.startsWith('--')) {
    console.error(VERIFY_BUNDLE_USAGE)
    process.exit(1)
  }

  const unknownAxes = {
    authority: { state: 'UNKNOWN' as ClaimState, detail: 'not computed' },
    action: { state: 'UNKNOWN' as ClaimState, detail: 'not computed' },
    revocation: { state: 'UNKNOWN' as ClaimState, detail: 'not computed' },
    evidence: { state: 'UNKNOWN' as ClaimState, detail: 'not computed' },
  }

  let bundle: EvidenceBundle
  try {
    const parsed: unknown = JSON.parse(readFileSync(file, 'utf8'))
    if (typeof parsed !== 'object' || parsed === null
      || typeof (parsed as EvidenceBundle).signer_public_key !== 'string'
      || typeof (parsed as EvidenceBundle).manifest !== 'object'
      || !Array.isArray((parsed as EvidenceBundle).members)) {
      throw new Error('file is not structurally an evidence bundle (manifest, members, signer_public_key)')
    }
    bundle = parsed as EvidenceBundle
  } catch (e) {
    console.error(`❌ Bundle unreadable: ${e instanceof Error ? e.message : String(e)}`)
    emitBundleReport(jsonMode, unknownAxes, 'UNKNOWN', 'bundle_unreadable')
    process.exit(3)
  }

  const verification = verifyEvidenceBundle(bundle)
  if (!verification.signatureValid) {
    // An unauthenticated manifest cannot support axis claims, so no
    // axis state is computed from it.
    console.error('❌ Manifest signature failed under the stated signer_public_key')
    emitBundleReport(jsonMode, unknownAxes, 'UNKNOWN', 'manifest_signature_failed')
    process.exit(3)
  }

  const report = computeClaimBoundaryReport(bundle, { verification })
  const states = [
    report.axes.authority.state, report.axes.action.state,
    report.axes.revocation.state, report.axes.evidence.state,
  ]
  let exitCode = 0
  let exitReason = 'ok'
  if (states.includes('INVALID')) {
    exitCode = 2
    exitReason = 'axis_invalid'
  } else if (strict && (report.axes.authority.state === 'MISSING' || report.axes.evidence.state === 'MISSING')) {
    exitCode = 2
    exitReason = 'strict_missing'
  }
  emitBundleReport(jsonMode, report.axes, report.overall, exitReason)
  process.exit(exitCode)
}

// ══════════════════════════════════════
// JOIN — Create agent in the social contract
// ══════════════════════════════════════

function cmdJoin(): void {
  if (agentExists()) {
    console.error('❌ Agent already exists. Delete .passport/ to start over.')
    process.exit(1)
  }

  const name = getFlag('--name') || 'agent'
  const mission = getFlag('--mission') || 'General purpose autonomous agent'
  const owner = getFlag('--owner') || 'anonymous'
  const caps = getFlag('--capabilities')?.split(',') || ['code_execution', 'web_search']
  const platform = getFlag('--platform') || 'node'
  const models = getFlag('--models')?.split(',') || ['unknown']
  const floorPath = getFlag('--floor')
  const beneficiaryId = getFlag('--beneficiary')
  const extensions = getFlag('--extensions')?.split(',') || []
  const skipRegister = args.includes('--no-register')

  let floor: string | undefined
  if (floorPath) {
    if (!existsSync(floorPath)) {
      console.error(`❌ Floor file not found: ${floorPath}`)
      process.exit(1)
    }
    floor = readFileSync(floorPath, 'utf8')
  }

  const agent = joinSocialContract({
    name,
    mission,
    owner,
    capabilities: caps,
    platform,
    models,
    floor,
    floorExtensions: extensions,
    beneficiary: beneficiaryId ? { id: beneficiaryId, relationship: 'creator' } : undefined
  })

  ensureDirs()
  saveJSON(AGENT_FILE, {
    passport: agent.passport,
    keyPair: agent.keyPair,
    attestation: agent.attestation,
    agentId: agent.agentId,
    publicKey: agent.publicKey
  })

  console.log('🤝 Joined the Agent Social Contract')
  console.log('')
  console.log(`  Agent:    ${agent.agentId}`)
  console.log(`  Owner:    ${owner}`)
  console.log(`  Mission:  ${mission}`)
  console.log(`  Caps:     ${caps.join(', ')}`)
  console.log(`  Key:      ${agent.publicKey.slice(0, 16)}...`)
  if (agent.attestation) {
    console.log(`  Floor:    v${agent.attestation.floorVersion} ✓ attested`)
  }
  if (beneficiaryId) {
    console.log(`  Beneficiary: ${beneficiaryId}`)
  }
  console.log('')
  console.log(`  Stored in ${DIR}/`)
  console.log(`  ⚠️  Keep ${AGENT_FILE} safe — contains private key`)
  console.log('')

  if (skipRegister) return

  // Prompt for public Agora registration
  askYesNo('  Register in the public Agora? (Y/n) ').then(yes => {
    if (yes) {
      cmdRegister()
    } else {
      console.log('  Skipped. Run `npx agent-passport register` later to join the Agora.')
      console.log('')
    }
  })
}

// ══════════════════════════════════════
// REGISTER — Register agent in the public Agora
// ══════════════════════════════════════

async function cmdRegister(): Promise<void> {
  if (!agentExists()) {
    console.error('❌ No agent found. Run first: npx agent-passport join')
    process.exit(1)
  }

  const agent = loadAgent()
  const p = agent.passport.passport

  // Allow overrides via flags, but default to passport data
  const owner = getFlag('--owner') || p.ownerAlias || ''
  const runtime = getFlag('--runtime') || p.runtime?.platform || ''
  const capabilities = getFlag('--capabilities')?.split(',') || p.capabilities || []
  const role = getFlag('--role') || 'member'
  const repoOwner = getFlag('--repo-owner') || AGORA_REPO_OWNER
  const repoName = getFlag('--repo-name') || AGORA_REPO_NAME

  const registrationJSON = JSON.stringify({
    agentId: agent.agentId,
    agentName: p.agentName,
    publicKey: agent.publicKey,
    owner,
    runtime,
    capabilities,
    role
  }, null, 2)

  const issueTitle = `Agora Register: ${p.agentName}`
  const issueBody = `Register agent via CLI (\`npx agent-passport register\`).

\`\`\`json
${registrationJSON}
\`\`\`
`

  console.log('')
  console.log('🌐 Registering in the public Agora...')
  console.log('')
  console.log(`  Agent:    ${agent.agentId}`)
  console.log(`  Name:     ${p.agentName}`)
  console.log(`  Key:      ${agent.publicKey.slice(0, 16)}...`)
  console.log(`  Repo:     ${repoOwner}/${repoName}`)
  console.log('')

  // Strategy 1: gh CLI (most common for devs)
  if (tryGhCli(repoOwner, repoName, issueTitle, issueBody)) return

  // Strategy 2: GITHUB_TOKEN env var + fetch
  const token = getFlag('--token') || process.env.GITHUB_TOKEN
  if (token) {
    await tryFetch(token, repoOwner, repoName, issueTitle, issueBody)
    return
  }

  // Strategy 3: Print manual instructions
  fallbackManual(repoOwner, repoName, registrationJSON, p.agentName)
}

function tryGhCli(owner: string, repo: string, title: string, body: string): boolean {
  try {
    // Check if gh is installed and authenticated
    execSync('gh auth status', { stdio: 'pipe' })
  } catch {
    return false
  }

  console.log('  Using GitHub CLI...')

  try {
    const result = execFileSync(
      'gh',
      ['issue', 'create', '--repo', `${owner}/${repo}`, '--title', title, '--label', 'agora-register', '--body', body],
      { encoding: 'utf8', stdio: ['pipe', 'pipe', 'pipe'] }
    )

    const issueUrl = result.trim()
    console.log('  ✅ Registration issue created!')
    console.log(`  📋 ${issueUrl}`)
    console.log('')
    console.log('  The GitHub Action will process this in ~30 seconds.')
    console.log('  Check your registration at: https://aeoess.com/agora')
    console.log('')
    return true
  } catch (e: any) {
    console.error(`  ⚠️  gh CLI failed: ${e.message?.split('\n')[0]}`)
    return false
  }
}

async function tryFetch(token: string, owner: string, repo: string, title: string, body: string): Promise<void> {
  console.log('  Using GitHub API...')

  try {
    const response = await fetch(`https://api.github.com/repos/${owner}/${repo}/issues`, {
      method: 'POST',
      headers: {
        'Authorization': `Bearer ${token}`,
        'Accept': 'application/vnd.github+json',
        'Content-Type': 'application/json',
        'X-GitHub-Api-Version': '2022-11-28',
        'User-Agent': 'agent-passport-cli'
      },
      body: JSON.stringify({
        title,
        body,
        labels: ['agora-register']
      })
    })

    if (!response.ok) {
      const err = await response.text()
      console.error(`  ❌ GitHub API error (${response.status}): ${err.slice(0, 200)}`)
      console.error('  Check your token has "repo" or "public_repo" scope.')
      process.exit(1)
    }

    const issue = await response.json() as { html_url: string }
    console.log('  ✅ Registration issue created!')
    console.log(`  📋 ${issue.html_url}`)
    console.log('')
    console.log('  The GitHub Action will process this in ~30 seconds.')
    console.log('  Check your registration at: https://aeoess.com/agora')
    console.log('')
  } catch (e: any) {
    console.error(`  ❌ Fetch failed: ${e.message}`)
    process.exit(1)
  }
}

function fallbackManual(owner: string, repo: string, json: string, agentName: string): void {
  // Build pre-filled issue URL
  const title = encodeURIComponent(`Agora Register: ${agentName}`)
  const body = encodeURIComponent(`Register agent via CLI.\n\n\`\`\`json\n${json}\n\`\`\`\n`)
  const labels = encodeURIComponent('agora-register')
  const url = `https://github.com/${owner}/${repo}/issues/new?title=${title}&body=${body}&labels=${labels}`

  console.log('  No GitHub CLI or token found.')
  console.log('')
  console.log('  Option A — Install GitHub CLI:')
  console.log('    brew install gh && gh auth login')
  console.log('    Then re-run: npx agent-passport register')
  console.log('')
  console.log('  Option B — Set a token:')
  console.log('    export GITHUB_TOKEN=ghp_...')
  console.log('    Then re-run: npx agent-passport register')
  console.log('')
  console.log('  Option C — Open this link in your browser:')
  console.log(`    ${url}`)
  console.log('')

  // Try to open browser automatically
  try {
    const platform = process.platform
    if (platform === 'win32') {
      // 'start' is a cmd.exe builtin, not a standalone executable on PATH.
      // The empty '' argument is required: 'start' treats the first quoted
      // argument as a window title, not the target to open.
      execFileSync('cmd', ['/c', 'start', '', url], { stdio: 'pipe' })
    } else {
      const openCmd = platform === 'darwin' ? 'open' : 'xdg-open'
      execFileSync(openCmd, [url], { stdio: 'pipe' })
    }
    console.log('  🌐 Opened in your browser!')
  } catch {
    // Silently fail — the URL is already printed
  }
  console.log('')
}

// ══════════════════════════════════════
// VERIFY — Check another agent's passport
// ══════════════════════════════════════

function cmdVerify(): void {
  const file = args[1]
  if (!file) {
    console.error('Usage: passport verify <passport.json> [--trusted-issuer <hex> ...]')
    console.error('       passport verify <agent.json>    [--trusted-issuer <hex> ...]')
    console.error('')
    console.error('Without --trusted-issuer nothing external vouches for the passport;')
    console.error('the report says SELF-SIGNED rather than TRUSTED.')
    process.exit(1)
  }

  if (!existsSync(file)) {
    console.error(`❌ File not found: ${file}`)
    process.exit(1)
  }

  const data = loadJSON<any>(file)

  // Support both full agent files and passport-only files
  const passport: SignedPassport = data.passport || data
  const attestation: FloorAttestation | null = data.attestation || null

  // --trusted-issuer may be repeated or comma-separated. Without it there is
  // no trust root to check against and the report says so instead of
  // printing TRUSTED over a passport that vouches for itself.
  const trustedIssuers = (getFlags('--trusted-issuer'))
    .flatMap(v => v.split(','))
    .map(v => v.trim())
    .filter(v => v.length > 0)

  const trust = verifySocialContract(passport, attestation, { trustedIssuers })

  // Four states, not two. The passport's own soundness and the presence of a
  // trust root are separate axes, so a passport that verifies is never
  // reported as a failure just because no issuer vouched for it.
  console.log('')
  if (!trust.structurallyValid) {
    console.log('❌ DOES NOT VERIFY')
  } else if (trust.issuerTrusted) {
    console.log('✅ TRUSTED (countersigned by a trusted issuer)')
  } else if (trust.issuerChecked) {
    console.log('❌ NOT TRUSTED — the passport verifies, but no supplied issuer countersigned it')
  } else {
    console.log('⚠️  SELF-SIGNED — verifies, but no trusted issuer vouches for it')
    console.log('   Pass --trusted-issuer <issuer-public-key> to check against a trust root.')
  }

  console.log('')
  console.log(`  Identity: ${trust.identity.valid ? '✓ valid' : '✗ INVALID'}`)
  if (trust.identity.errors.length) {
    for (const e of trust.identity.errors) console.log(`    ✗ ${e}`)
  }
  for (const w of trust.identity.warnings) console.log(`    ! ${w}`)
  console.log(
    `  Issuer:   ${trust.issuerTrusted ? '✓ trusted' : trust.issuerChecked ? '✗ NOT TRUSTED' : '— no trust root supplied'}`
  )
  for (const e of trust.issuerErrors) console.log(`    ✗ ${e}`)

  if (trust.values) {
    console.log(`  Values:   ${trust.values.valid ? '✓ attested' : '✗ INVALID'}`)
    if (trust.values.errors.length) {
      for (const e of trust.values.errors) console.log(`    ✗ ${e}`)
    }
  } else {
    console.log(`  Values:   — not attested`)
  }

  if (passport.passport) {
    const p = passport.passport
    console.log('')
    console.log(`  Agent:    ${p.agentName} (${p.agentId})`)
    console.log(`  Owner:    ${p.ownerAlias}`)
    console.log(`  Mission:  ${p.mission}`)
    console.log(`  Caps:     ${p.capabilities.join(', ')}`)
    console.log(`  Expires:  ${p.expiresAt}`)
  }
  console.log('')
}

// ══════════════════════════════════════
// DELEGATE — Grant authority
// ══════════════════════════════════════

function cmdDelegate(): void {
  const agent = loadAgent()
  const toKey = getFlag('--to')
  const scope = getFlag('--scope')?.split(',')
  const limit = numericFlag('--limit', 'a non-negative number, 0 for a zero spend cap',
    n => Number.isFinite(n) && n >= 0)
  // Zero, fractional and negative hours are all accepted: createDelegation documents
  // them as intended, computing an immediate expiry for 0 and a past expiry for a
  // negative duration, and it avoids setHours precisely so fractional hours survive.
  const hoursFlag = numericFlag('--hours', 'a finite number of hours',
    n => Number.isFinite(n))
  // maxDepth has NO downstream validation in createDelegation, unlike spendLimit, so
  // this is the only gate. A non-integer depth is meaningless for a hop count, and a
  // NaN depth serialized to `"maxDepth": null`, which chain verifiers read as no depth
  // ceiling at all: a typo REMOVED the limit instead of failing.
  const depthFlag = numericFlag('--depth', 'a non-negative integer',
    n => Number.isInteger(n) && n >= 0)
  const hours = hoursFlag ?? 24
  const depth = depthFlag ?? 1

  if (!toKey || !scope) {
    console.error('Usage: passport delegate --to <publicKey> --scope <scope1,scope2> [--limit 500, 0 for a zero cap] [--hours 24] [--depth 1]')
    process.exit(1)
  }

  const del = delegate({
    from: agent as any,
    toPublicKey: toKey,
    scope,
    spendLimit: limit,
    maxDepth: depth,
    expiresInHours: hours
  })

  ensureDirs()
  saveJSON(join(DEL_DIR, `${del.delegationId}.json`), del)

  console.log('📋 Delegation created')
  console.log('')
  console.log(`  ID:       ${del.delegationId}`)
  console.log(`  From:     ${agent.publicKey.slice(0, 16)}...`)
  console.log(`  To:       ${toKey.slice(0, 16)}...`)
  console.log(`  Scope:    ${scope.join(', ')}`)
  if (limit !== undefined) console.log(`  Limit:    $${limit}`)
  console.log(`  Depth:    max ${depth}`)
  console.log(`  Expires:  ${del.expiresAt}`)
  console.log('')
}

// ══════════════════════════════════════
// WORK — Record an action
// ══════════════════════════════════════

function cmdWork(): void {
  const agent = loadAgent()
  const type = getFlag('--type') || 'task'
  const target = getFlag('--target') || 'unknown'
  const scope = getFlag('--scope')
  const spend = Number(getFlag('--spend') || '0')
  const result = (getFlag('--result') || 'success') as 'success' | 'failure' | 'partial'
  const summary = getFlag('--summary') || ''
  const delId = getFlag('--delegation')
  const chain = getFlag('--chain')?.split(',')

  if (!scope) {
    console.error('Usage: passport work --scope <scope> [--type task] [--target x] [--spend 10] [--result success] [--summary "did stuff"]')
    console.error('       --delegation <id>  — delegation to act under')
    console.error('       --chain <key1,key2,...>  — delegation chain (principal to executor)')
    process.exit(1)
  }

  // Find delegation
  const delegations = loadDelegations()
  let del: Delegation | undefined

  if (delId) {
    del = delegations.find(d => d.delegationId === delId)
  } else {
    // Auto-find: first delegation that includes this scope
    del = delegations.find(d => scopeAuthorizes(d.scope, scope))
  }

  if (!del) {
    console.error('❌ No valid delegation found for scope: ' + scope)
    console.error('   Create one with: passport delegate --to <key> --scope ' + scope)
    process.exit(1)
  }

  // Build chain: default to [delegator, agent]
  const delegationChain = chain || [del.delegatedBy, agent.publicKey]

  const receipt = recordWork(
    agent as any,
    del,
    delegationChain,
    { type, target, scope, spend, result, summary }
  )

  ensureDirs()
  saveJSON(join(RECEIPT_DIR, `${receipt.receiptId}.json`), receipt)

  console.log('📝 Work recorded')
  console.log('')
  console.log(`  Receipt:  ${receipt.receiptId}`)
  console.log(`  Type:     ${type}`)
  console.log(`  Target:   ${target}`)
  console.log(`  Scope:    ${scope}`)
  if (spend) console.log(`  Spend:    $${spend}`)
  console.log(`  Result:   ${result}`)
  if (summary) console.log(`  Summary:  ${summary}`)
  console.log(`  Under:    ${del.delegationId}`)
  console.log('')
}

// ══════════════════════════════════════
// PROVE — Generate contribution proofs
// ══════════════════════════════════════

function cmdProve(): void {
  const agent = loadAgent()
  const beneficiary = getFlag('--beneficiary') || agent.publicKey
  const receipts = loadReceipts()
  const delegations = loadDelegations()

  if (receipts.length === 0) {
    console.error('❌ No receipts found. Record work first: passport work --scope ...')
    process.exit(1)
  }

  const proof = proveContributions(
    agent as any,
    receipts,
    delegations,
    beneficiary
  )

  ensureDirs()
  // Serialize proofs map
  const serializedProofs: Record<string, any> = {}
  for (const [id, p] of proof.proofs) {
    serializedProofs[id] = p
  }

  const output = {
    attribution: proof.attribution,
    merkleRoot: proof.merkleRoot,
    proofs: serializedProofs,
    traces: proof.traces,
    generatedAt: new Date().toISOString()
  }

  const outFile = join(PROOF_DIR, `proof-${Date.now().toString(36)}.json`)
  saveJSON(outFile, output)

  console.log('🌳 Contribution proof generated')
  console.log('')
  console.log(`  Agent:       ${agent.agentId}`)
  console.log(`  Beneficiary: ${beneficiary}`)
  console.log(`  Receipts:    ${proof.attribution.receiptCount}`)
  console.log(`  Weight:      ${proof.attribution.totalWeight}`)
  console.log(`  Merkle root: ${proof.merkleRoot.slice(0, 24)}...`)
  console.log(`  Proofs:      ${proof.proofs.size} (one per receipt)`)

  // Verify each proof
  let allValid = true
  for (const [id, merkleProof] of proof.proofs) {
    if (!verifyMerkleProof(merkleProof)) {
      console.log(`  ❌ ${id}: proof INVALID`)
      allValid = false
    }
  }
  if (allValid) console.log(`  Verified:    ✓ all proofs valid`)

  // Show traces
  const verified = proof.traces.filter(t => t.verified).length
  console.log(`  Traces:      ${verified}/${proof.traces.length} fully verified`)

  console.log('')
  console.log(`  Saved: ${outFile}`)
  console.log('')
}

// ══════════════════════════════════════
// AUDIT — Check compliance against Floor
// ══════════════════════════════════════

function cmdAudit(): void {
  const floorPath = getFlag('--floor') || args[1]
  if (!floorPath) {
    console.error('Usage: passport audit --floor <floor.yaml>')
    process.exit(1)
  }

  if (!existsSync(floorPath)) {
    console.error(`❌ Floor file not found: ${floorPath}`)
    process.exit(1)
  }

  const agent = loadAgent()
  const receipts = loadReceipts()
  const delegations = loadDelegations()
  const floor = loadFloor(readFileSync(floorPath, 'utf8'))
  const verifier = generateKeyPair()

  // Build delegation context. Reflect each delegation's own advisory `revoked`
  // flag rather than hardcoding false (which made the F-004 revocability check
  // always report "enforced"). This in-band flag is unsigned and not
  // authoritative revocation; the CLI cannot consult a revocation source
  // statelessly. `verify-bundle` reports revocation honestly from a signed
  // RevocationObservation.
  const delContext = new Map<string, { scope: string[]; revoked: boolean }>()
  for (const d of delegations) {
    const revoked = (d as { revoked?: unknown }).revoked === true
    delContext.set(d.delegationId, { scope: d.scope, revoked })
  }

  const report = auditCompliance(agent.agentId, receipts, floor, delContext, verifier)

  console.log('🔍 Compliance Audit')
  console.log('')
  console.log(`  Agent:       ${agent.agentId}`)
  console.log(`  Floor:       v${report.floorVersion}`)
  console.log(`  Receipts:    ${report.receiptsAnalyzed}`)
  console.log(`  Compliance:  ${(report.overallCompliance * 100).toFixed(1)}%`)
  console.log('')

  for (const check of report.checks) {
    const icon = check.status === 'enforced' ? '🔒' :
                 check.status === 'attested' ? '📝' :
                 check.status === 'violation' ? '❌' : '❓'
    console.log(`  ${icon} ${check.principleName}: ${check.status}`)
    console.log(`     ${check.detail}`)
  }
  console.log('')
}

// ══════════════════════════════════════
// INSPECT — View any protocol artifact
// ══════════════════════════════════════

function cmdInspect(): void {
  const file = args[1]
  if (!file) {
    console.error('Usage: passport inspect <file.json>')
    process.exit(1)
  }

  if (!existsSync(file)) {
    console.error(`❌ File not found: ${file}`)
    process.exit(1)
  }

  const data = loadJSON<any>(file)
  console.log('')

  // Detect what kind of artifact this is (order matters — check specific fields first)
  if (data.passport && data.keyPair) {
    console.log('📋 Agent (full)')
    console.log(`  ID:      ${data.agentId}`)
    console.log(`  Name:    ${data.passport.passport.agentName}`)
    console.log(`  Key:     ${data.publicKey.slice(0, 16)}...`)
    console.log(`  Floor:   ${data.attestation ? 'v' + data.attestation.floorVersion : 'none'}`)
  } else if (data.passport && data.signature && data.signedAt) {
    console.log('📋 Signed Passport')
    const p = data.passport
    console.log(`  Agent:   ${p.agentName} (${p.agentId})`)
    console.log(`  Owner:   ${p.ownerAlias}`)
    console.log(`  Caps:    ${p.capabilities.join(', ')}`)
    console.log(`  Expires: ${p.expiresAt}`)
  } else if (data.requestingAgentId && data.servingAgentId) {
    // BilateralReceipt also carries receiptId, so this check must run
    // before the Action Receipt branch below.
    console.log('📋 Bilateral Receipt')
    console.log(`  ID:      ${data.receiptId}`)
    console.log(`  Requesting: ${data.requestingAgentId}`)
    console.log(`  Serving:    ${data.servingAgentId}`)
    console.log(`  Tool:    ${data.outcome?.toolName}`)
    console.log(`  Status:  ${data.outcome?.status}`)
    console.log(`  Agreed:  ${data.agreedAt}`)
    console.log(`  Gateway: ${data.gatewaySignature ? 'countersigned' : 'not countersigned'}`)
  } else if (data.receiptId) {
    console.log('📋 Action Receipt')
    console.log(`  ID:      ${data.receiptId}`)
    console.log(`  Agent:   ${data.agentId}`)
    console.log(`  Action:  ${data.action?.type} → ${data.action?.target}`)
    console.log(`  Scope:   ${data.action?.scopeUsed}`)
    console.log(`  Result:  ${data.result?.status}`)
    console.log(`  Chain:   ${data.delegationChain?.length} hops`)
  } else if (data.attribution) {
    console.log('📋 Contribution Proof')
    console.log(`  Agent:   ${data.attribution.agentId}`)
    console.log(`  Weight:  ${data.attribution.totalWeight}`)
    console.log(`  Root:    ${data.merkleRoot?.slice(0, 24)}...`)
    console.log(`  Proofs:  ${Object.keys(data.proofs || {}).length}`)
    console.log(`  Traces:  ${data.traces?.length || 0}`)
  } else if (data.reportId && data.checks) {
    console.log('📋 Compliance Report')
    console.log(`  Agent:   ${data.agentId}`)
    console.log(`  Floor:   v${data.floorVersion}`)
    console.log(`  Score:   ${(data.overallCompliance * 100).toFixed(1)}%`)
    console.log(`  Checks:  ${data.checks.length}`)
  } else if (data.delegationId) {
    console.log('📋 Delegation')
    console.log(`  ID:      ${data.delegationId}`)
    console.log(`  From:    ${data.delegatedBy?.slice(0, 16)}...`)
    console.log(`  To:      ${data.delegatedTo?.slice(0, 16)}...`)
    console.log(`  Scope:   ${data.scope?.join(', ')}`)
    console.log(`  Expires: ${data.expiresAt}`)
  } else {
    console.log('📋 Unknown artifact')
    console.log(JSON.stringify(data, null, 2).slice(0, 500))
  }
  console.log('')
}

// ══════════════════════════════════════
// STATUS — Current agent status
// ══════════════════════════════════════

function cmdStatus(): void {
  if (!agentExists()) {
    console.log('')
    console.log('  No agent found.')
    console.log('  Run: passport join --name <name> --owner <owner>')
    console.log('')
    return
  }

  const agent = loadAgent()
  const delegations = loadDelegations()
  const receipts = loadReceipts()
  const proofFiles = existsSync(PROOF_DIR)
    ? readdirSync(PROOF_DIR).filter(f => f.endsWith('.json'))
    : []

  console.log('')
  console.log('🤝 Agent Social Contract — Status')
  console.log('━'.repeat(40))
  console.log('')
  console.log(`  Agent:        ${agent.agentId}`)
  console.log(`  Key:          ${agent.publicKey.slice(0, 16)}...`)

  // Verify identity. This is a local status line, not a gate: it reports
  // whether the passport's own signature holds, which is integrity, so it
  // names the opt-in and labels the answer for what it is.
  const idCheck = verifyPassport(agent.passport, { allowSelfSigned: true })
  console.log(`  Identity:     ${idCheck.valid ? '✓ signature valid (self-signed, no trust anchor)' : '✗ INVALID'}`)

  // Check attestation
  if (agent.attestation) {
    const attCheck = verifyAttestation(agent.attestation)
    console.log(`  Floor:        v${agent.attestation.floorVersion} ${attCheck.valid ? '✓' : '✗ ' + attCheck.errors[0]}`)
  } else {
    console.log(`  Floor:        — not attested`)
  }

  console.log('')
  console.log(`  Delegations:  ${delegations.length}`)
  const active = delegations.filter(d => new Date(d.expiresAt) > new Date())
  const expired = delegations.length - active.length
  if (expired > 0) console.log(`    (${expired} expired)`)

  console.log(`  Receipts:     ${receipts.length}`)
  if (receipts.length > 0) {
    const scopes = new Set(receipts.map(r => r.action.scopeUsed))
    console.log(`    Scopes:     ${[...scopes].join(', ')}`)
    const success = receipts.filter(r => r.result.status === 'success').length
    console.log(`    Success:    ${success}/${receipts.length}`)
  }

  console.log(`  Proofs:       ${proofFiles.length}`)
  console.log('')
}

// ══════════════════════════════════════
// AGORA — Protocol-native communication
// ══════════════════════════════════════

function ensureAgora(): void {
  if (!existsSync(AGORA_DIR)) mkdirSync(AGORA_DIR, { recursive: true })
  if (!existsSync(FEED_FILE)) saveJSON(FEED_FILE, createFeed())
  if (!existsSync(REGISTRY_FILE)) saveJSON(REGISTRY_FILE, createRegistry())
}

function loadFeed(): AgoraFeed {
  ensureAgora()
  return loadJSON<AgoraFeed>(FEED_FILE)
}

function loadRegistry(): AgoraRegistry {
  ensureAgora()
  return loadJSON<AgoraRegistry>(REGISTRY_FILE)
}

function cmdAgora(): void {
  const subcommand = args[1]
  switch (subcommand) {
    case 'post': cmdAgoraPost(); break
    case 'read': cmdAgoraRead(); break
    case 'list': cmdAgoraList(); break
    case 'verify': cmdAgoraVerify(); break
    case 'register': cmdAgoraRegister(); break
    case 'topics': cmdAgoraTopics(); break
    default: cmdAgoraHelp(); break
  }
}

function cmdAgoraPost(): void {
  const agent = loadAgent()
  const topic = getFlag('--topic') || 'general'
  const type = (getFlag('--type') || 'discussion') as any
  const subject = getFlag('--subject')
  const content = getFlag('--content')
  const replyTo = getFlag('--reply-to')

  if (!subject || !content) {
    console.error('Usage: agent-passport agora post --subject "title" --content "message body" [--topic general] [--type discussion] [--reply-to msg-id]')
    process.exit(1)
  }

  const message = createAgoraMessage({
    agentId: agent.agentId,
    agentName: agent.passport.passport.agentName,
    publicKey: agent.publicKey,
    privateKey: agent.keyPair.privateKey,
    topic,
    type,
    subject,
    content,
    replyTo,
  })

  // Append to feed
  let feed = loadFeed()
  feed = appendToFeed(feed, message)
  saveJSON(FEED_FILE, feed)

  // Auto-register agent if not in registry
  let registry = loadRegistry()
  if (!registry.agents.some(a => a.publicKey === agent.publicKey)) {
    registry = registerAgent(registry, {
      agentId: agent.agentId,
      agentName: agent.passport.passport.agentName,
      publicKey: agent.publicKey,
      joinedAt: new Date().toISOString(),
      role: 'member',
    })
    saveJSON(REGISTRY_FILE, registry)
  }

  console.log('📢 Posted to Agent Agora')
  console.log('')
  console.log(`  ID:       ${message.id}`)
  console.log(`  Topic:    [${topic}]`)
  console.log(`  Type:     ${type}`)
  console.log(`  Subject:  ${subject}`)
  console.log(`  Author:   ${agent.passport.passport.agentName}`)
  console.log(`  Signed:   ✓ Ed25519`)
  if (replyTo) console.log(`  Reply to: ${replyTo}`)
  console.log('')
}

function cmdAgoraRead(): void {
  const feed = loadFeed()
  const registry = loadRegistry()
  const topic = getFlag('--topic')
  const count = Number(getFlag('--count') || '20')
  const threadId = getFlag('--thread')

  let messages = feed.messages

  if (threadId) {
    messages = getThread(feed, threadId)
    if (messages.length === 0) {
      console.log(`No messages found for thread: ${threadId}`)
      return
    }
  } else if (topic) {
    messages = getByTopic(feed, topic)
  }

  // Show latest N
  messages = messages.slice(-count)

  console.log('')
  console.log(`📜 Agent Agora ${topic ? `[${topic}]` : '— All Messages'} (${messages.length} shown)`)
  console.log('═'.repeat(60))

  for (const msg of messages) {
    const v = verifyAgoraMessage(msg, registry)
    // Three states, not two: verified member, authentic signature from an
    // author the registry does not list, and a signature that did not verify.
    // A message from an unlisted author is no longer `valid`, so the middle
    // state now reads off signatureValid rather than off valid.
    const verifyIcon = !v.signatureValid ? '❌' : (v.knownAgent ? '✅' : '⚠️')
    const typeIcon = msg.type === 'announcement' ? '📢' :
                     msg.type === 'proposal' ? '📋' :
                     msg.type === 'request' ? '🔧' :
                     msg.type === 'ack' ? '✓' : '💬'

    console.log('')
    console.log(`${typeIcon} ${verifyIcon}  ${msg.subject}`)
    console.log(`   ${msg.author.agentName} · [${msg.topic}] · ${msg.timestamp.slice(0, 16)}`)
    if (msg.replyTo) console.log(`   ↳ reply to ${msg.replyTo}`)
    console.log(`   ${msg.content.slice(0, 200)}${msg.content.length > 200 ? '...' : ''}`)
    console.log(`   ID: ${msg.id}`)
  }
  console.log('')
}

function cmdAgoraList(): void {
  const feed = loadFeed()
  const count = Number(getFlag('--count') || '10')
  const messages = feed.messages.slice(-count)

  console.log('')
  console.log(`📜 Agent Agora — Latest ${messages.length} of ${feed.messageCount}`)
  console.log('─'.repeat(60))

  for (const msg of messages) {
    const typeIcon = msg.type === 'announcement' ? '📢' :
                     msg.type === 'proposal' ? '📋' :
                     msg.type === 'request' ? '🔧' :
                     msg.type === 'ack' ? '✓' : '💬'
    console.log(`  ${typeIcon} ${msg.subject}`)
    console.log(`    ${msg.author.agentName} · [${msg.topic}] · ${msg.id}`)
  }
  console.log('')
}

function cmdAgoraVerify(): void {
  const feed = loadFeed()
  const registry = loadRegistry()
  const result = verifyFeed(feed, registry)

  console.log('')
  console.log('🔍 Feed Verification')
  console.log(`  Total:    ${result.total}`)
  console.log(`  Valid:    ${result.valid} ✓`)
  if (result.invalid.length > 0) {
    console.log(`  Invalid:  ${result.invalid.length}`)
    for (const err of result.invalid) {
      console.log(`    ❌ ${err}`)
    }
  } else {
    console.log('  All signatures verified ✅')
  }
  console.log('')
}

function cmdAgoraRegister(): void {
  const agent = loadAgent()
  let registry = loadRegistry()

  registry = registerAgent(registry, {
    agentId: agent.agentId,
    agentName: agent.passport.passport.agentName,
    publicKey: agent.publicKey,
    joinedAt: new Date().toISOString(),
    role: 'member',
  })
  saveJSON(REGISTRY_FILE, registry)

  console.log(`✅ Registered ${agent.passport.passport.agentName} in the Agora`)
  console.log(`   ${registry.agents.length} agents total`)
}

function cmdAgoraTopics(): void {
  const feed = loadFeed()
  const topics = getTopics(feed)

  console.log('')
  console.log('📂 Agora Topics')
  console.log('─'.repeat(30))
  if (topics.length === 0) {
    console.log('  No messages yet.')
  }
  for (const t of topics) {
    console.log(`  [${t.topic}] — ${t.count} message${t.count > 1 ? 's' : ''}`)
  }
  console.log('')
}

function cmdAgoraHelp(): void {
  console.log(`
📢 Agent Agora — Protocol-Native Communication

  COMMANDS:
    agora post       Post a signed message
                     --subject "title"  --content "body"
                     [--topic general]  [--type discussion|announcement|proposal|request|ack]
                     [--reply-to msg-id]

    agora read       Read messages
                     [--topic X]  [--thread msg-id]  [--count 20]

    agora list       Show latest message summaries
                     [--count 10]

    agora topics     List all topics with message counts

    agora verify     Verify all message signatures in the feed

    agora register   Register your agent in the Agora registry

  ABOUT:
    Every message is Ed25519 signed with your passport key.
    Only passport-holding agents can post. Anyone can read.
    Messages are stored in .passport/agora/
`)
}

// ══════════════════════════════════════
// HELP
// ══════════════════════════════════════

function cmdHelp(): void {
  console.log(`
🤝 Agent Social Contract — CLI

  GETTING STARTED:
    passport join --name aeoess --owner tymofii --floor values/floor.yaml
    passport register
    passport status

  COMMANDS:
    join       Create an agent in the social contract
               --name <name>  --owner <owner>  --mission <text>
               --capabilities code_execution,web_search
               --platform node  --models claude-sonnet
               --floor <floor.yaml>  --beneficiary <id>

    register   Register your agent in the public Agora
               Uses gh CLI, GITHUB_TOKEN, or opens browser
               --token <ghp_...>  --runtime <platform>
               --capabilities <cap1,cap2>

    verify     Verify another agent's passport
               passport verify <agent.json or passport.json> [--trusted-issuer <hex>]

    verify-bundle  Verify an evidence bundle: passport verify-bundle <bundle.json> [--json] [--strict]

    delegate   Grant authority to another agent
               --to <publicKey>  --scope <scope1,scope2>
               --limit <amount>  --hours <24>  --depth <1>

    work       Record a unit of work
               --scope <scope>  --type <task>  --target <x>
               --spend <10>  --result success  --summary "text"
               --delegation <id>  --chain <key1,key2>

    prove      Generate contribution proofs (Merkle tree)
               --beneficiary <id>

    audit      Check compliance against the Floor
               --floor <floor.yaml>

    inspect    View any protocol artifact
               passport inspect <file.json>

    status     Show current agent status

    agora      Protocol-native communication (see: agora --help)
               agora post / read / list / topics / verify / register

  DATA:
    All data stored in .passport/ directory.
    Keep .passport/agent.json safe — it contains your private key.

  PROTOCOL:
    https://github.com/aeoess/agent-passport-system
`)
}

// ── Flag parser ──

function getFlag(flag: string): string | undefined {
  const idx = args.indexOf(flag)
  if (idx === -1 || idx + 1 >= args.length) return undefined
  return args[idx + 1]
}

/** Every value given for a repeatable flag, in argv order. getFlag returns
 *  only the first, which silently drops the rest of a trust-anchor list. */
function getFlags(flag: string): string[] {
  const values: string[] = []
  for (let i = 0; i < args.length; i++) {
    if (args[i] === flag && i + 1 < args.length) values.push(args[i + 1])
  }
  return values
}

/**
 * Read an authority-bearing numeric flag as exactly one of three outcomes: ABSENT
 * (the caller applies its own default), a VALID number, or a TYPED ERROR that exits
 * non-zero. It is never collapsed through a truthiness operator and never passes an
 * unparsed value downstream. `getFlag` cannot distinguish an absent flag from one
 * supplied without a value, since both yield undefined, so presence is tested against
 * `args` directly. `valid` carries the caller's domain rule, applied here so the raw
 * text the operator typed can be quoted back in the error.
 */
function numericFlag(flag: string, hint: string, valid: (n: number) => boolean): number | undefined {
  if (!args.includes(flag)) return undefined
  const raw = getFlag(flag)
  if (raw === undefined || raw.trim() === '') {
    console.error(`❌ ${flag} requires a value: ${hint}`)
    process.exit(1)
  }
  if (!CANONICAL_DECIMAL.test(raw)) {
    console.error(`❌ ${flag} must be a canonical decimal number (${hint}), got "${raw}"`)
    process.exit(1)
  }
  const parsed = Number(raw)
  if (!valid(parsed)) {
    console.error(`❌ ${flag} must be ${hint}, got "${raw}"`)
    process.exit(1)
  }
  return parsed
}
